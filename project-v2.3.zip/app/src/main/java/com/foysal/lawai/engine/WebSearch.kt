package com.foysal.lawai.engine

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Looks things up on bdlaws.minlaw.gov.bd (the Ministry of Law's official
 * "Laws of Bangladesh" site) when the phone is online.
 *
 * This is a best-effort extra, not the main source. The site has no public
 * API, so we read its search page and pull out act titles and links. If the
 * site changes its markup this quietly returns nothing rather than breaking
 * the app - the offline answer from the user's own books still stands.
 */
object WebSearch {

    private const val BASE = "https://bdlaws.minlaw.gov.bd"

    class Item(val title: String, val url: String)

    class Result(val items: List<Item>, val error: String?)

    fun isOnline(): Boolean = try {
        val c = URL("$BASE/").openConnection() as HttpURLConnection
        c.connectTimeout = 5000
        c.readTimeout = 5000
        c.requestMethod = "HEAD"
        val ok = c.responseCode in 200..399
        c.disconnect()
        ok
    } catch (e: Exception) {
        false
    }

    fun search(query: String, limit: Int = 5): Result {
        return try {
            val q = URLEncoder.encode(query.take(120), "UTF-8")
            val html = fetch("$BASE/search_home.php?search=$q")
                ?: return Result(emptyList(), "সাইটে পৌঁছানো যায়নি")
            Result(parse(html, limit), null)
        } catch (e: Exception) {
            Result(emptyList(), e.message ?: "অনুসন্ধানে সমস্যা")
        }
    }

    private val LINK = Regex(
        "<a[^>]+href=\"([^\"]*act[^\"]*)\"[^>]*>(.*?)</a>",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    )
    private val TAG = Regex("<[^>]+>")

    private fun parse(html: String, limit: Int): List<Item> {
        val out = ArrayList<Item>()
        val seen = HashSet<String>()
        for (m in LINK.findAll(html)) {
            var href = m.groupValues[1].trim()
            val title = TAG.replace(m.groupValues[2], " ")
                .replace("&amp;", "&")
                .replace("&nbsp;", " ")
                .replace(Regex("\\s+"), " ")
                .trim()
            if (title.length < 6) continue
            if (!href.startsWith("http")) {
                href = BASE + "/" + href.removePrefix("/")
            }
            if (seen.add(href)) {
                out.add(Item(title, href))
                if (out.size >= limit) break
            }
        }
        return out
    }

    /**
     * Pulls readable Bangla text out of an act page, so the user sees the
     * actual law - not just a link - when it is not in their own books.
     * Best-effort: returns a trimmed excerpt or null.
     */
    fun fetchActText(url: String, maxChars: Int = 2500): String? {
        val html = fetch(url) ?: return null
        // strip scripts/styles, turn block tags into newlines, drop the rest
        var t = html
            .replace(Regex("(?is)<script.*?</script>"), " ")
            .replace(Regex("(?is)<style.*?</style>"), " ")
            .replace(Regex("(?i)<(br|/p|/div|/tr|/li|/h[1-6])[^>]*>"), "\n")
            .replace(Regex("<[^>]+>"), " ")
            .replace("&nbsp;", " ").replace("&amp;", "&")
            .replace("&lt;", "<").replace("&gt;", ">")
        // keep lines that actually contain Bangla
        val lines = t.split("\n")
            .map { it.replace(Regex("[ \t]+"), " ").trim() }
            .filter { line -> line.length > 3 && line.count { it in '\u0980'..'\u09FF' } > 2 }
        val joined = lines.joinToString("\n")
        if (joined.isBlank()) return null
        return if (joined.length > maxChars) joined.substring(0, maxChars) + " …" else joined
    }

    private fun fetch(urlStr: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            conn = URL(urlStr).openConnection() as HttpURLConnection
            conn.connectTimeout = 10000
            conn.readTimeout = 20000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) AinShohayok")
            if (conn.responseCode !in 200..299) return null
            BufferedReader(InputStreamReader(conn.inputStream, "UTF-8")).use { it.readText() }
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}
