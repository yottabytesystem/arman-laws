package com.foysal.lawai.engine

import android.content.Context
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.InputStream

/**
 * Pulls the text layer out of a PDF.
 *
 * Note on legacy Bangla PDFs: gazette files usually store Bangla as ASCII
 * glyph codes for a Bijoy font, so what comes out here looks like mojibake
 * ("evsjv‡`k †M‡RU"). That is expected - [BijoyConverter] repairs it
 * afterwards. What this cannot do is read a scanned PDF, because an image
 * of text has no text layer at all; those need OCR first.
 */
object PdfText {

    private var initialised = false

    private fun ensureInit(context: Context) {
        if (!initialised) {
            PDFBoxResourceLoader.init(context.applicationContext)
            initialised = true
        }
    }

    class Result(
        val text: String,
        val pageCount: Int,
        val error: String?
    )

    fun extract(context: Context, input: InputStream): Result {
        ensureInit(context)
        var doc: PDDocument? = null
        return try {
            doc = PDDocument.load(input)
            if (doc.isEncrypted) {
                return Result("", 0, "পিডিএফটি পাসওয়ার্ড দিয়ে সুরক্ষিত")
            }
            val pages = doc.numberOfPages
            val stripper = PDFTextStripper()
            stripper.sortByPosition = true
            stripper.lineSeparator = "\n"
            stripper.paragraphEnd = "\n"
            val text = stripper.getText(doc)
            if (text.isBlank()) {
                Result("", pages, "এই পিডিএফে কোনো লেখা নেই - সম্ভবত স্ক্যান করা ছবি")
            } else {
                Result(text, pages, null)
            }
        } catch (e: OutOfMemoryError) {
            Result("", 0, "পিডিএফটি খুব বড়, মেমোরিতে ধরছে না")
        } catch (e: Exception) {
            Result("", 0, "পিডিএফ পড়া যায়নি: " + (e.message ?: "অজানা ত্রুটি"))
        } finally {
            try {
                doc?.close()
            } catch (_: Exception) {
            }
        }
    }

    fun looksLikePdf(name: String, firstBytes: ByteArray?): Boolean {
        if (name.endsWith(".pdf", ignoreCase = true)) return true
        if (firstBytes != null && firstBytes.size >= 4) {
            return firstBytes[0] == '%'.code.toByte() &&
                firstBytes[1] == 'P'.code.toByte() &&
                firstBytes[2] == 'D'.code.toByte() &&
                firstBytes[3] == 'F'.code.toByte()
        }
        return false
    }
}
