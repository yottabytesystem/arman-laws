package com.foysal.lawai.data

data class Book(
    val id: Long,
    val title: String,
    val fileName: String,
    val sectionCount: Int
)

/**
 * One retrievable unit of law. For statutes this is a single
 * প্রবিধান / ধারা / বিধি, which is exactly what a citation must point to.
 */
data class Section(
    val id: Long,
    val bookId: Long,
    val bookTitle: String,
    val chapter: String,
    val number: String,
    val heading: String,
    val body: String
) {
    val citation: String
        get() = buildString {
            append(bookTitle)
            if (number.isNotBlank()) append(", ধারা/প্রবিধান ").append(number)
            if (chapter.isNotBlank()) append(" (").append(chapter).append(")")
        }

    val displayTitle: String
        get() = buildString {
            if (number.isNotBlank()) append(number).append(". ")
            append(if (heading.isNotBlank()) heading else body.take(40))
        }
}

data class Hit(
    val section: Section,
    val score: Double,
    val matchedTerms: List<String>
)
