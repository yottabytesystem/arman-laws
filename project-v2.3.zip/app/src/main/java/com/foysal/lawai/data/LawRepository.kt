package com.foysal.lawai.data

import android.content.Context
import android.net.Uri
import com.foysal.lawai.engine.BijoyConverter
import com.foysal.lawai.engine.BookParser
import com.foysal.lawai.engine.DocxText
import com.foysal.lawai.engine.PdfText
import com.foysal.lawai.engine.SearchEngine
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Owns the database, the search index and book import.
 */
class LawRepository(private val context: Context) {

    private val db = LawDatabase(context)
    val engine = SearchEngine()

    /** Copies the bundled book(s) in on first launch, then builds the index. */
    private val prefs by lazy {
        context.getSharedPreferences("armanlaws_prefs", Context.MODE_PRIVATE)
    }

    fun initialize(progress: (String) -> Unit) {
        try {
            val removed = prefs.getStringSet("removed_assets", emptySet()) ?: emptySet()
            val assets = context.assets.list("books") ?: emptyArray()
            for (name in assets) {
                if (!name.endsWith(".txt", true)) continue
                if (name in removed) continue          // user deleted it - respect that
                if (db.hasBook(name)) continue
                progress("Loading: $name")
                val text = context.assets.open("books/$name").use { readAll(it) }
                importText(text, name)
            }
        } catch (e: Exception) {
            progress("Asset load error: ${e.message}")
        }
        rebuildIndex(progress)
    }

    fun rebuildIndex(progress: (String) -> Unit) {
        progress("সূচি তৈরি হচ্ছে...")
        val sections = db.loadAllSections()
        engine.build(sections)
        progress("প্রস্তুত")
    }

    private fun readAll(input: java.io.InputStream): String {
        BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { r ->
            return r.readText()
        }
    }

    /**
     * Import a plain-text law book. Bijoy-encoded text is auto-detected and
     * converted to Unicode, otherwise search would never match anything.
     */
    fun importText(raw: String, fileName: String, titleHint: String? = null): ImportResult {
        var text = raw.replace("\r\n", "\n").replace('\r', '\n')
        var converted = false
        if (BijoyConverter.looksLikeBijoy(text)) {
            text = BijoyConverter.convert(text)
            converted = true
        }
        val title = titleHint ?: BookParser.guessTitle(text, fileName.removeSuffix(".txt"))
        val parsed = BookParser.parse(text)
        if (parsed.isEmpty()) {
            return ImportResult(false, title, 0, converted, "কোনো পাঠযোগ্য অংশ পাওয়া যায়নি")
        }
        val bookId = db.insertBook(title, fileName)
        db.insertSections(bookId, parsed.map { arrayOf(it.chapter, it.number, it.heading, it.body) })
        return ImportResult(true, title, parsed.size, converted, null)
    }

    fun importFromUri(uri: Uri, displayName: String): ImportResult {
        return try {
            // Sniff the header so a .pdf renamed to .txt still works.
            val head = context.contentResolver.openInputStream(uri)?.use { input ->
                val b = ByteArray(4)
                val n = input.read(b)
                if (n == 4) b else null
            }

            if (DocxText.looksLikeDocx(displayName, head)) {
                val res = context.contentResolver.openInputStream(uri)?.use { input ->
                    DocxText.extract(input)
                } ?: return ImportResult(false, displayName, 0, false, "ফাইল খোলা যায়নি")
                if (res.error != null) {
                    return ImportResult(false, displayName, 0, false, res.error)
                }
                return importText(res.text, displayName.substringBeforeLast('.') + ".txt")
            }

            if (PdfText.looksLikePdf(displayName, head)) {
                val res = context.contentResolver.openInputStream(uri)?.use { input ->
                    PdfText.extract(context, input)
                } ?: return ImportResult(false, displayName, 0, false, "ফাইল খোলা যায়নি")

                if (res.error != null) {
                    return ImportResult(false, displayName, 0, false, res.error)
                }
                return importText(res.text, displayName.removeSuffix(".pdf") + ".txt")
            }

            val text = context.contentResolver.openInputStream(uri)?.use { readAll(it) }
                ?: return ImportResult(false, displayName, 0, false, "ফাইল খোলা যায়নি")
            importText(text, displayName)
        } catch (e: Exception) {
            ImportResult(false, displayName, 0, false, e.message ?: "অজানা ত্রুটি")
        }
    }

    /**
     * Pulls plain text out of an attached PDF / DOCX / TXT so it can be added
     * to a question as extra context (an office order, a notice, etc). Works
     * offline - no API needed. Bijoy is auto-converted. Returns "" on failure.
     */
    fun extractAttachmentText(uri: Uri, displayName: String): String {
        return try {
            val head = context.contentResolver.openInputStream(uri)?.use { input ->
                val b = ByteArray(4); val n = input.read(b); if (n == 4) b else null
            }
            val raw = when {
                DocxText.looksLikeDocx(displayName, head) ->
                    context.contentResolver.openInputStream(uri)?.use { DocxText.extract(it).text } ?: ""
                PdfText.looksLikePdf(displayName, head) ->
                    context.contentResolver.openInputStream(uri)?.use { PdfText.extract(context, it).text } ?: ""
                else ->
                    context.contentResolver.openInputStream(uri)?.use { readAll(it) } ?: ""
            }
            if (BijoyConverter.looksLikeBijoy(raw)) BijoyConverter.convert(raw) else raw
        } catch (e: Exception) {
            ""
        }
    }

    fun books(): List<Book> = db.listBooks()

    fun deleteBook(id: Long) {
        val fileName = db.fileNameOf(id)
        db.deleteBook(id)
        if (fileName != null) {
            val cur = prefs.getStringSet("removed_assets", emptySet())?.toMutableSet() ?: mutableSetOf()
            cur.add(fileName)
            prefs.edit().putStringSet("removed_assets", cur).apply()
        }
    }

    fun stats(): Pair<Int, Int> = Pair(books().size, engine.size)

    data class ImportResult(
        val ok: Boolean,
        val title: String,
        val sectionCount: Int,
        val bijoyConverted: Boolean,
        val error: String?
    )
}
