package com.foysal.lawai.engine

/**
 * Bengali text utilities: normalisation, tokenisation, light stemming,
 * stop-word removal and legal synonym expansion.
 *
 * These matter far more than they look. Bengali is highly inflected, so
 * "ছুটির", "ছুটিতে" and "ছুটি" must all collapse to one index term or recall
 * collapses.
 */
object BengaliText {

    private val BENGALI_DIGITS = charArrayOf(
        '\u09E6', '\u09E7', '\u09E8', '\u09E9', '\u09EA',
        '\u09EB', '\u09EC', '\u09ED', '\u09EE', '\u09EF'
    )

    /** Convert Bengali digits to ASCII so "৩২" and "32" match. */
    fun digitsToAscii(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            val idx = BENGALI_DIGITS.indexOf(c)
            if (idx >= 0) sb.append(('0' + idx)) else sb.append(c)
        }
        return sb.toString()
    }

    fun asciiToBengaliDigits(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            if (c in '0'..'9') sb.append(BENGALI_DIGITS[c - '0']) else sb.append(c)
        }
        return sb.toString()
    }

    /**
     * Folds spellings that Bengali writers routinely mix up, so a query still
     * matches when the book spells it differently:
     *   ি/ী, ু/ূ, ন/ণ, শ/ষ/স, জ/য, র/ড়/ঢ়, ঙ/ং
     * Used for indexing and lookup only - never for display.
     */
    fun fold(input: String): String {
        val sb = StringBuilder(input.length)
        for (c in normalize(input)) {
            sb.append(
                when (c) {
                    '\u09C0' -> '\u09BF'   // ী -> ি
                    '\u09C2' -> '\u09C1'   // ূ -> ু
                    '\u09A3' -> '\u09A8'   // ণ -> ন
                    '\u09B7', '\u09B6' -> '\u09B8'  // ষ, শ -> স
                    '\u09AF' -> '\u099C'   // য -> জ
                    '\u09DC', '\u09DD' -> '\u09B0'  // ড়, ঢ় -> র
                    '\u0999' -> '\u0982'   // ঙ -> ং
                    '\u09E1', '\u098B' -> '\u09B0'  // ৡ, ঋ -> র
                    else -> c
                }
            )
        }
        return sb.toString()
    }

    /** Canonical form: strip ZWJ/ZWNJ, unify nukta forms, drop chandrabindu. */
    fun normalize(input: String): String {
        var s = input
            .replace("\u200C", "")
            .replace("\u200D", "")
            .replace("\u09AF\u09BC", "\u09DF")
            .replace("\u09A1\u09BC", "\u09DC")
            .replace("\u09A2\u09BC", "\u09DD")
            .replace("\u0981", "")
        s = digitsToAscii(s)
        return s
    }

    private val SEPARATOR = Regex("[^\\u0980-\\u09FFA-Za-z0-9]+")

    fun tokenize(text: String): List<String> =
        normalize(text).split(SEPARATOR).filter { it.isNotBlank() }

    /** Common Bengali function words that carry no retrieval signal. */
    private val STOPWORDS: Set<String> = setOf(
        "এই", "ওই", "সেই", "এবং", "বা", "কিন্তু", "তবে", "যে", "যা", "যাহা",
        "করা", "করে", "করিয়া", "করিতে", "হয়", "হইবে", "হইয়া", "হইতে", "হবে",
        "থেকে", "হতে", "জন্য", "সঙ্গে", "সহিত", "মধ্যে", "উপর", "নিচে",
        "কোন", "কোনো", "কিছু", "সব", "সকল", "অন্য", "আর", "ও", "এর", "তার",
        "আমি", "আমার", "আমাকে", "আমরা", "তুমি", "তোমার", "সে", "তিনি", "তাহার",
        "না", "নাই", "নয়", "হলে", "যদি", "তাহলে", "কি", "কী", "কেন", "কিভাবে",
        "একটি", "একটা", "টি", "টা", "মত", "মতো", "পর", "আগে", "সময়", "এখন",
        "বলিতে", "বুঝাইবে", "উক্ত", "তথা", "ইহার", "ইহা", "যাহাতে", "অথবা",
        "the", "a", "an", "of", "in", "to", "and", "or", "for", "is", "be"
    )

    fun isStopword(w: String) = w in STOPWORDS

    /**
     * Light suffix stripper. Deliberately conservative - over-stemming Bengali
     * destroys meaning (ধারা vs ধারাবাহিক).
     */
    private val SUFFIXES: List<String> = listOf(
        "েরাই", "গুলোর", "গুলিতে", "গুলোতে", "দেরকে", "টিতে", "টাতে",
        "গুলো", "গুলি", "দের", "েরা", "ের", "কে", "তে", "য়ে", "রা",
        "টির", "টার", "টি", "টা", "খানা", "খানি", "সমূহ", "মালার", "মালা",
        "ই", "ও", "য়", "র"
    )

    fun stem(word: String): String {
        if (word.length <= 3) return word
        for (suf in SUFFIXES) {
            if (word.length - suf.length >= 3 && word.endsWith(suf)) {
                return word.dropLast(suf.length)
            }
        }
        return word
    }

    /**
     * Domain synonyms. A user writes "চাকরি" but the statute says "চাকুরী";
     * without this the search silently returns nothing.
     */
    private val SYNONYM_GROUPS: List<Set<String>> = listOf(
        setOf("চাকরি", "চাকুরি", "চাকুরী", "চাকরী", "কর্ম", "কাজ", "নিয়োগ"),
        setOf("ছুটি", "অবকাশ", "ছুট", "লিভ", "leave"),
        setOf("বেতন", "মজুরি", "মজুরী", "বেতনভাতা", "পারিশ্রমিক", "salary", "wage"),
        setOf("বরখাস্ত", "অপসারণ", "চাকরিচ্যুত", "বহিষ্কার", "ডিসমিস", "অব্যাহতি"),
        setOf("শাস্তি", "দণ্ড", "জরিমানা", "শাস্তিমূলক", "দণ্ডমূলক"),
        setOf("শৃঙ্খলা", "শৃংখলা", "অসদাচরণ", "অনিয়ম", "দুর্নীতি", "অপরাধ"),
        setOf("অনুপস্থিত", "অনুপস্থিতি", "গরহাজির", "পলায়ন", "অননুমোদিত"),
        setOf("পদোন্নতি", "প্রমোশন", "উন্নীত", "পদায়ন"),
        setOf("অবসর", "পেনশন", "অবসরগ্রহণ", "রিটায়ার", "গ্র্যাচুইটি", "গ্রাচুইটি"),
        setOf("আপিল", "আপীল", "অভিযোগ", "দরখাস্ত", "আবেদন", "রিভিউ", "পুনর্বিবেচনা"),
        setOf("বদলি", "স্থানান্তর", "প্রেষণ", "সংযুক্তি"),
        setOf("নোটিশ", "নোটিস", "বিজ্ঞপ্তি", "প্রজ্ঞাপন", "পরিপত্র"),
        setOf("কর্তৃপক্ষ", "বোর্ড", "নিয়োগকারী", "কর্তৃপক্ষের"),
        setOf("কর্মচারী", "কর্মকর্তা", "স্টাফ", "কর্মী"),
        setOf("সাময়িক", "সাময়িকভাবে", "সাসপেন্ড", "সাসপেনশন", "স্থগিত"),
        setOf("তদন্ত", "অনুসন্ধান", "তদন্তকারী", "কমিটি"),
        setOf("প্রবিধান", "ধারা", "বিধি", "উপবিধি", "অনুচ্ছেদ", "অধ্যায়"),
        setOf("পদত্যাগ", "ইস্তফা", "ইস্তফাদান", "রিজাইন", "ত্যাগ", "ছাড়", "অবসান"),
        setOf("প্রশিক্ষণ", "ট্রেনিং", "শিক্ষানবিশ", "শিক্ষানবিসি"),
        setOf("ভাতা", "সুবিধা", "প্রাপ্য", "সুযোগ")
    )

    private val SYNONYM_INDEX: Map<String, Set<String>> = buildMap {
        for (group in SYNONYM_GROUPS) {
            for (w in group) put(fold(w), group.map { fold(it) }.toSet())
        }
    }

    fun expand(term: String): Set<String> {
        val n = fold(term)
        val direct = SYNONYM_INDEX[n]
        if (direct != null) return direct
        val st = stem(n)
        for ((k, v) in SYNONYM_INDEX) {
            if (stem(k) == st) return v
        }
        return setOf(n)
    }

    /** Content terms of a query, stop-words removed, stemmed and spelling-folded. */
    fun contentTerms(text: String): List<String> =
        tokenize(text)
            .filter { it.length > 1 && !isStopword(it) }
            .map { fold(stem(it)) }
            .filter { it.isNotBlank() }
}
