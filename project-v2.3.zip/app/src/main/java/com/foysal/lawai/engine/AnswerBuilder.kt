package com.foysal.lawai.engine

import com.foysal.lawai.data.Hit
import com.foysal.lawai.data.Section

/**
 * Turns raw retrieval hits into a readable legal answer with citations.
 *
 * This is deliberately rule-based and quotes the statute verbatim. It never
 * invents legal text - every sentence of law shown comes straight out of a book
 * the user loaded, with the section number attached.
 */
object AnswerBuilder {

    private data class Topic(
        val name: String,
        val keys: List<String>,
        val steps: List<String>
    )

    private val TOPICS = listOf(
        Topic(
            "ছুটি সংক্রান্ত", listOf("ছুটি", "অবকাশ", "অনুপস্থিত", "গরহাজির", "পলায়ন"),
            listOf(
                "ছুটির আবেদন লিখিতভাবে জমা দিন এবং প্রাপ্তি স্বীকারপত্র রাখুন",
                "প্রযোজ্য ধারায় নির্ধারিত সর্বোচ্চ মেয়াদ মিলিয়ে দেখুন",
                "অনুমোদন ছাড়া অনুপস্থিত থাকলে শৃঙ্খলা ধারা প্রযোজ্য হতে পারে"
            )
        ),
        Topic(
            "বেতন ও ভাতা", listOf("বেতন", "মজুরি", "ভাতা", "গ্র্যাচুইটি", "পেনশন", "প্রাপ্য"),
            listOf(
                "বেতন নির্ধারণের তফসিল ও স্কেল যাচাই করুন",
                "বকেয়া থাকলে লিখিত দাবিপত্র দিন, তারিখ উল্লেখ করে",
                "নিষ্পত্তি না হলে নির্ধারিত আপিল কর্তৃপক্ষের কাছে যান"
            )
        ),
        Topic(
            "শৃঙ্খলা ও শাস্তি", listOf("শৃঙ্খলা", "অসদাচরণ", "শাস্তি", "দণ্ড", "বরখাস্ত", "তদন্ত", "অভিযোগ"),
            listOf(
                "অভিযোগনামা ও কারণ দর্শানো নোটিশ সংগ্রহ করুন",
                "নির্ধারিত সময়ের মধ্যে লিখিত জবাব দিন",
                "তদন্ত কমিটিতে আত্মপক্ষ সমর্থনের সুযোগ দাবি করুন",
                "দণ্ড আরোপ হলে আপিলের মেয়াদ গণনা শুরু করুন"
            )
        ),
        Topic(
            "নিয়োগ ও পদোন্নতি", listOf("নিয়োগ", "পদোন্নতি", "যোগ্যতা", "শিক্ষানবিশ", "পদায়ন", "জ্যেষ্ঠতা"),
            listOf(
                "পদের নির্ধারিত যোগ্যতা ও তফসিল মিলিয়ে দেখুন",
                "জ্যেষ্ঠতার তালিকা ও নিয়োগপত্র সংগ্রহ করুন",
                "অনিয়ম মনে হলে নির্ধারিত সময়ে লিখিত আপত্তি দিন"
            )
        ),
        Topic(
            "অবসর ও চাকরি অবসান", listOf("অবসর", "পদত্যাগ", "ইস্তফা", "অবসান", "চাকরিচ্যুত"),
            listOf(
                "নোটিশের মেয়াদ ও প্রযোজ্য শর্ত যাচাই করুন",
                "চূড়ান্ত পাওনা (গ্র্যাচুইটি, ছুটি নগদায়ন) হিসাব করুন",
                "ছাড়পত্র ও চূড়ান্ত হিসাব লিখিতভাবে চান"
            )
        ),
        Topic(
            "বদলি ও প্রেষণ", listOf("বদলি", "স্থানান্তর", "প্রেষণ", "সংযুক্তি"),
            listOf(
                "বদলি আদেশের কর্তৃত্ব ও ধারা যাচাই করুন",
                "যোগদানের সময়সীমা ও ভ্রমণ ভাতা দেখুন"
            )
        ),
        Topic(
            "আপিল ও প্রতিকার", listOf("আপিল", "আপীল", "পুনর্বিবেচনা", "রিভিউ", "প্রতিকার", "দরখাস্ত"),
            listOf(
                "আপিলের নির্ধারিত সময়সীমা মিস করবেন না",
                "কোন কর্তৃপক্ষের কাছে আপিল যাবে তা ধারায় দেখুন",
                "সব নথির অনুলিপি সংযুক্ত করুন"
            )
        )
    )

    private fun detectTopics(query: String): List<Topic> {
        val q = BengaliText.normalize(query)
        return TOPICS.filter { t -> t.keys.any { q.contains(BengaliText.normalize(it)) } }
    }

    fun build(
        query: String,
        hits: List<Hit>,
        totalBooks: Int,
        totalSections: Int,
        definitions: List<Pair<String, String>> = emptyList(),
        related: List<Section> = emptyList()
    ): String {
        val sb = StringBuilder()

        if (hits.isEmpty()) {
            sb.append("❌ এই প্রশ্নের সাথে মিল আছে এমন কোনো ধারা পাওয়া যায়নি।\n\n")
            sb.append("পরামর্শ:\n")
            sb.append("• অন্য শব্দে চেষ্টা করুন (যেমন \"ছুটি\", \"বেতন\", \"শাস্তি\")\n")
            sb.append("• সংশ্লিষ্ট আইন বইটি \"বই যোগ করুন\" দিয়ে যোগ করুন\n\n")
            sb.append("বর্তমানে লোড আছে: $totalBooks টি বই, $totalSections টি ধারা।")
            return sb.toString()
        }

        val topics = detectTopics(query)
        sb.append("🔍 বিশ্লেষণ\n")
        sb.append("─────────────────────────\n")
        if (topics.isNotEmpty()) {
            sb.append("বিষয়: ").append(topics.joinToString(", ") { it.name }).append("\n")
        }
        sb.append("প্রাসঙ্গিক ধারা পাওয়া গেছে: ").append(hits.size).append("টি\n\n")

        sb.append("⚖️ প্রযোজ্য আইন\n")
        sb.append("─────────────────────────\n")

        val top = hits.first().score
        hits.forEachIndexed { i, h ->
            val pct = if (top > 0) (h.score / top * 100).toInt() else 0
            sb.append("\n【 ").append(i + 1).append(" 】 ")
            if (h.section.number.isNotBlank()) {
                sb.append("ধারা/প্রবিধান ").append(BengaliText.asciiToBengaliDigits(h.section.number))
            } else {
                sb.append("অংশ")
            }
            sb.append("   (মিল ").append(BengaliText.asciiToBengaliDigits(pct.toString())).append("%)\n")

            if (h.section.heading.isNotBlank()) {
                sb.append("শিরোনাম: ").append(h.section.heading).append("\n")
            }
            if (h.section.chapter.isNotBlank()) {
                sb.append("অধ্যায়: ").append(h.section.chapter).append("\n")
            }
            sb.append("\n").append(h.section.body.trim()).append("\n")
            sb.append("\n📖 বই: ").append(h.section.bookTitle)
                .append("  |  ").append(h.section.citation).append("\n")
            if (h.matchedTerms.isNotEmpty()) {
                sb.append("🔑 মিলে যাওয়া শব্দ: ")
                    .append(h.matchedTerms.take(6).joinToString(", "))
                    .append("\n")
            }
            sb.append("─────────────────────────\n")
        }

        if (topics.isNotEmpty()) {
            sb.append("\n📋 সম্ভাব্য পদক্ষেপ\n")
            sb.append("─────────────────────────\n")
            var n = 1
            for (t in topics) {
                for (s in t.steps) {
                    sb.append(BengaliText.asciiToBengaliDigits(n.toString()))
                        .append(". ").append(s).append("\n")
                    n++
                }
            }
        }

        if (definitions.isNotEmpty()) {
            sb.append("\n📖 আইনি সংজ্ঞা\n─────────────────────────\n")
            for ((term, text) in definitions) {
                sb.append("• ").append(text).append("\n")
            }
            sb.append("─────────────────────────\n")
        }

        if (related.isNotEmpty()) {
            sb.append("\n🔗 সম্পর্কিত ধারা (উল্লেখ থেকে)\n")
            sb.append("─────────────────────────\n")
            for (r in related) {
                val num = BengaliText.asciiToBengaliDigits(r.number)
                sb.append("▸ ধারা ").append(num)
                if (r.heading.isNotBlank()) sb.append(" — ").append(r.heading)
                sb.append("\n").append(r.body.trim().take(220))
                if (r.body.length > 220) sb.append("…")
                sb.append("\n\n")
            }
        }

        return sb.toString()
    }

    /** Compact context handed to the AI when an API key is configured. */
    fun contextForAi(hits: List<Hit>): String = buildString {
        for (h in hits) {
            append("[").append(h.section.citation).append("]\n")
            if (h.section.heading.isNotBlank()) append(h.section.heading).append("\n")
            append(h.section.body.trim()).append("\n\n")
        }
    }

    /** Appended when the phone is online and the law site returned links. */
    fun webBlock(items: List<WebSearch.Item>): String {
        if (items.isEmpty()) return ""
        val sb = StringBuilder()
        sb.append("\n\n──── ইন্টারনেট থেকে ────\n")
        sb.append("(bdlaws.minlaw.gov.bd — সরকারি আইন ভাণ্ডার)\n\n")
        for (it in items) {
            sb.append("• ").append(it.title).append("\n  ").append(it.url).append("\n")
        }
        return sb.toString()
    }
}
