package com.foysal.lawai.engine

import com.foysal.lawai.data.Hit
import com.foysal.lawai.data.Section
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/**
 * In-memory BM25 retrieval over every indexed section of every book.
 *
 * BM25 is the same ranking family used by Elasticsearch and Lucene. On a legal
 * corpus it beats naive keyword counting because it discounts terms that occur
 * everywhere ("কর্মচারী") and rewards rare, discriminating terms ("গ্র্যাচুইটি").
 */
class SearchEngine {

    private class Posting(val sectionIdx: Int, val tf: Int, val inHeading: Boolean)

    private val sections = ArrayList<Section>()
    private val postings = HashMap<String, ArrayList<Posting>>()
    private val docLen = ArrayList<Int>()
    private val numberIndex = HashMap<String, ArrayList<Int>>()
    private var avgDocLen = 1.0

    private val SECTION_REF =
        Regex("প্রবিধান|ধারা|বিধি|অনুচ্ছেদ|উপ-?প্রবিধান|section", RegexOption.IGNORE_CASE)

    private val k1 = 1.5
    private val b = 0.75

    val size: Int get() = sections.size

    fun clear() {
        sections.clear(); postings.clear(); docLen.clear(); numberIndex.clear()
        avgDocLen = 1.0
    }

    fun build(input: List<Section>) {
        clear()
        sections.addAll(input)
        var totalLen = 0L

        for ((idx, s) in sections.withIndex()) {
            val headingTerms = BengaliText.contentTerms(s.heading).toSet()
            val terms = BengaliText.contentTerms(s.heading + " " + s.body)
            val tfMap = HashMap<String, Int>()
            for (t in terms) tfMap[t] = (tfMap[t] ?: 0) + 1

            for ((term, tf) in tfMap) {
                postings.getOrPut(term) { ArrayList() }
                    .add(Posting(idx, tf, term in headingTerms))
            }
            docLen.add(terms.size)
            totalLen += terms.size

            if (s.number.isNotBlank()) {
                numberIndex.getOrPut(s.number) { ArrayList() }.add(idx)
            }
        }
        avgDocLen = if (sections.isEmpty()) 1.0 else totalLen.toDouble() / sections.size
    }

    private fun idf(df: Int): Double {
        val n = sections.size.toDouble()
        return ln(1.0 + (n - df + 0.5) / (df + 0.5))
    }

    /**
     * @param weight lower for synonym-expanded terms so the user's own wording
     *               still dominates the ranking.
     */
    private fun accumulate(
        term: String,
        weight: Double,
        scores: HashMap<Int, Double>,
        matched: HashMap<Int, MutableSet<String>>
    ) {
        val plist = postings[term] ?: return
        val termIdf = idf(plist.size)
        for (p in plist) {
            val dl = docLen[p.sectionIdx].toDouble()
            val denom = p.tf + k1 * (1 - b + b * dl / avgDocLen)
            var s = termIdf * (p.tf * (k1 + 1)) / max(denom, 1e-9)
            if (p.inHeading) s *= 3.0
            scores[p.sectionIdx] = (scores[p.sectionIdx] ?: 0.0) + s * weight
            matched.getOrPut(p.sectionIdx) { linkedSetOf() }.add(term)
        }
    }

    fun search(query: String, limit: Int = 8): List<Hit> {
        if (sections.isEmpty()) return emptyList()

        val scores = HashMap<Int, Double>()
        val matched = HashMap<Int, MutableSet<String>>()

        val queryTerms = BengaliText.contentTerms(query)
        if (queryTerms.isEmpty()) return emptyList()

        for (raw in queryTerms) {
            accumulate(raw, 1.0, scores, matched)
            for (syn in BengaliText.expand(raw)) {
                val st = BengaliText.stem(syn)
                if (st != raw) accumulate(st, 0.45, scores, matched)
            }
        }

        // Direct section-number lookup, but ONLY when the user is actually
        // citing a section. Otherwise "৬০ দিন অনুপস্থিত" wrongly boosts
        // section 60, which has nothing to do with absence.
        if (SECTION_REF.containsMatchIn(query)) {
            val asciiQuery = BengaliText.digitsToAscii(query)
            for (m in Regex("\\b(\\d{1,3})\\b").findAll(asciiQuery)) {
                numberIndex[m.groupValues[1]]?.forEach { idx ->
                    scores[idx] = (scores[idx] ?: 0.0) + 12.0
                    matched.getOrPut(idx) { linkedSetOf() }.add("ধারা " + m.groupValues[1])
                }
            }
        }

        // Proximity bonus: reward sections containing the terms close together.
        val qSet = queryTerms.toSet()
        if (qSet.size >= 2) {
            for (idx in scores.keys.toList()) {
                val hitCount = matched[idx]?.count { it in qSet } ?: 0
                if (hitCount >= 2) {
                    scores[idx] = scores[idx]!! * (1.0 + 0.18 * min(hitCount, 5))
                }
            }
        }

        return scores.entries
            .sortedByDescending { it.value }
            .take(limit)
            .map { (idx, sc) ->
                Hit(sections[idx], sc, (matched[idx] ?: emptySet<String>()).toList())
            }
            .filter { it.score > 0.5 }
    }

    fun sectionByNumber(number: String): List<Section> =
        numberIndex[BengaliText.digitsToAscii(number)]?.map { sections[it] } ?: emptyList()

    fun allSections(): List<Section> = sections

    /** First section carrying each number - used for cross-reference lookup. */
    fun firstByNumberMap(): Map<String, Section> {
        val m = LinkedHashMap<String, Section>()
        for (s in sections) {
            if (s.number.isNotBlank() && !s.number.startsWith("তফসিল-") && s.number !in m) {
                m[s.number] = s
            }
        }
        return m
    }

    /**
     * Definitions live in the "সংজ্ঞা" section (usually ধারা ২), each as
     * (ক) "term" বলিতে ... বুঝাইবে;  -  pull the ones a query mentions.
     */
    private val DEF_ITEM = Regex(
        "[\u0995-\u09B9]\\)\\s*[\u201C\u0022]([^\u201D\u0022]{2,40})[\u201D\u0022]\\s*বলিতে(.*?)(?=[\u0995-\u09B9]\\)\\s*[\u201C\u0022]|$)",
        RegexOption.DOT_MATCHES_ALL
    )

    fun definitionsFor(query: String): List<Pair<String, String>> {
        val defSec = sections.firstOrNull {
            it.heading.contains("সংজ্ঞা") || it.body.take(40).contains("সংজ্ঞা")
        } ?: return emptyList()
        val qTerms = BengaliText.contentTerms(query).toSet()
        if (qTerms.isEmpty()) return emptyList()
        val out = ArrayList<Pair<String, String>>()
        for (m in DEF_ITEM.findAll(defSec.body)) {
            val term = m.groupValues[1].trim()
            val termKey = BengaliText.contentTerms(term).firstOrNull() ?: continue
            if (qTerms.any { it.contains(termKey) || termKey.contains(it) }) {
                val text = ("“" + term + "” বলিতে" + m.groupValues[2]).trim()
                    .trimEnd(';', '।', ' ')
                out.add(term to text)
                if (out.size >= 3) break
            }
        }
        return out
    }

    /**
     * Sections that the given hits point to via "প্রবিধান ৪২ মোতাবেক" style
     * references, so the reader gets the referenced law without searching again.
     * Same-book only, de-duplicated against the hits themselves.
     */
    fun crossReferences(hits: List<Hit>, maxExtra: Int = 3): List<Section> {
        val already = hits.mapNotNull { it.section.number.ifBlank { null } }.toMutableSet()
        val out = LinkedHashMap<String, Section>()
        val refWord = Regex("(?:প্রবিধান|ধারা|বিধি|উপ-?প্রবিধান)\\s*([\\u09E6-\\u09EF0-9]{1,3})")
        for (h in hits) {
            val bookId = h.section.bookId
            for (m in refWord.findAll(h.section.body)) {
                val num = BengaliText.digitsToAscii(m.groupValues[1])
                if (num == h.section.number || num in already) continue
                val target = sections.firstOrNull { it.bookId == bookId && it.number == num }
                if (target != null && target.number !in out) {
                    out[target.number] = target
                    already.add(num)
                    if (out.size >= maxExtra) return out.values.toList()
                }
            }
        }
        return out.values.toList()
    }
}
