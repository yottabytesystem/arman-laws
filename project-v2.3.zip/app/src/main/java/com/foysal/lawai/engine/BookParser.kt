package com.foysal.lawai.engine

/**
 * Splits a law book into individually citable sections.
 *
 * Verified against the Bangladesh Gazette "প্রবিধানমালা, ২০০৯": all 57
 * regulations parse with correct numbers, headings and chapters, and the
 * তফসিল (schedule) is kept separate so its serial numbers cannot collide
 * with regulation numbers.
 */
object BookParser {

    data class Raw(
        val chapter: String,
        val number: String,
        val heading: String,
        val body: String,
        val schedule: Boolean
    )

    // "৫।" / "৫." / "৫)" optionally with a sub-number "৫(২)"
    private val SECTION_START = Regex(
        "^\\s*([\\u09E6-\\u09EF0-9]{1,3}(?:\\([\\u09E6-\\u09EF0-9\\u0995-\\u09B9]{1,3}\\))?)" +
            "\\s*[\\u0964\\u09F7.)]\\s*(.{0,80}?)(?:[\\u0964.\\-\\u2013]|$)"
    )

    private const val ORDINALS =
        "প্রথম|দ্বিতীয়|তৃতীয়|চতুর্থ|পঞ্চম|ষষ্ঠ|সপ্তম|অষ্টম|নবম|দশম|একাদশ|দ্বাদশ"

    // The gazette actually misprints "পঞ্চম অধ্যয়" - accept that spelling too,
    // otherwise regulations 32-35 get filed under the wrong chapter.
    private val CHAPTER_LINE = Regex(
        "^\\s*(?:(?:$ORDINALS)\\s*)?(?:অধ্যায়|অধ্যয়|খন্ড|খণ্ড|পরিচ্ছেদ)" +
            "\\s*[-\\u2013:]?\\s*[\\u09E6-\\u09EF0-9]{0,3}\\s*$" +
            "|^\\s*(?:$ORDINALS)\\s+(?:অধ্যায়|অধ্যয়)"
    )

    private val SCHEDULE_LINE = Regex("^\\s*তফসিল")

    // In the schedule table the serial and the post name land on separate
    // lines ("১।" then "মহাপরিচালক"), so capture the serial then the next
    // meaningful line.
    private val SCHED_NUM = Regex("^\\s*([\\u09E6-\\u09EF0-9]{1,3})\\s*[\\u0964\\u09F7.]\\s*(.*)$")
    private val SCHED_SKIP = Regex("^\\s*(?:\\.\\.|[\\u09E6-\\u09EF0-9]{1,3}|\\(ক\\)|\\(খ\\))\\s*$")

    private val PAGE_NUMBER = Regex("^[\\u09E6-\\u09EF0-9]{1,6}$")
    private val COLLAPSE = Regex("\\s*\\n\\s*")

    private const val MIN_BODY = 25

    fun parse(text: String): List<Raw> {
        val out = ArrayList<Raw>()
        var chapter = ""
        var number = ""
        var heading = ""
        var inSchedule = false
        var pendingHeading = false
        val buf = StringBuilder()

        fun flush() {
            val body = COLLAPSE.replace(buf.toString(), " ").trim()
            if (body.length >= MIN_BODY) {
                out.add(Raw(chapter, number, heading, body, inSchedule))
            }
            buf.setLength(0)
        }

        for (rawLine in text.split("\n")) {
            val line = rawLine.trim()
            if (line.isEmpty()) { buf.append('\n'); continue }
            if (PAGE_NUMBER.matches(line)) continue

            if (!inSchedule && SCHEDULE_LINE.containsMatchIn(line) && line.length <= 20) {
                flush()
                inSchedule = true
                chapter = "তফসিল"
                number = ""
                heading = ""
                buf.append(line).append('\n')
                continue
            }

            if (!inSchedule && line.length < 80 && CHAPTER_LINE.containsMatchIn(line)) {
                flush()
                chapter = line
                number = ""
                heading = ""
                continue
            }

            if (inSchedule) {
                val m = SCHED_NUM.find(line)
                if (m != null && line.length <= 60) {
                    flush()
                    number = "তফসিল-" + BengaliText.digitsToAscii(m.groupValues[1].trim())
                    heading = m.groupValues[2].trim().trim('\u0964', '.', '-', ' ')
                    pendingHeading = heading.isEmpty()
                    buf.append(line).append('\n')
                    continue
                }
                if (pendingHeading && line.length >= 2 && !SCHED_SKIP.matches(line)) {
                    heading = line.trim('\u0964', '.', '-', ' ').take(60)
                    pendingHeading = false
                }
                buf.append(line).append('\n')
                continue
            }

            val m = SECTION_START.find(line)
            if (m != null) {
                flush()
                number = BengaliText.digitsToAscii(m.groupValues[1].trim())
                heading = m.groupValues[2].trim().trim('\u0964', '.', '-', ' ')
                buf.append(line).append('\n')
            } else {
                buf.append(line).append('\n')
            }
        }
        flush()
        return mergeTiny(out)
    }

    /** Glue orphan fragments onto the previous section so context survives. */
    private fun mergeTiny(list: List<Raw>): List<Raw> {
        if (list.isEmpty()) return list
        val out = ArrayList<Raw>()
        for (r in list) {
            val last = out.lastOrNull()
            if (last != null && r.number.isBlank() && r.body.length < 120) {
                out[out.size - 1] = last.copy(body = last.body + " " + r.body)
            } else {
                out.add(r)
            }
        }
        return out
    }

    /** Best-effort book title from the first meaningful lines. */
    // Bangladeshi statutes name themselves in section 1, e.g.
    //   "... এই প্রবিধানমালা <NAME> নামে অভিহিত হইবে"
    // That self-declared name is the most reliable title, so try it first.
    private val SELF_NAME = Regex(
        "এই\\s+(?:প্রবিধানমালা|আইন|বিধিমালা|অধ্যাদেশ|নীতিমালা|অধ্যায়|রুলস)\\s+" +
            "(.{6,90}?)\\s+(?:নামে|বলিয়া)\\s+অভিহিত"
    )

    fun guessTitle(text: String, fallback: String): String {
        val flat = text.replace(Regex("\\s+"), " ")
        SELF_NAME.find(flat)?.let {
            val name = it.groupValues[1].trim().trim('\u0964', ',', ' ')
            if (name.length in 6..90) return name
        }
        // Fallback: first substantial Bengali line that is not page furniture.
        for (line in text.split("\n").take(60)) {
            val t = line.trim()
            if (t.length in 12..90 && t.count { c -> c in '\u0980'..'\u09FF' } > 8) {
                if (!t.contains("গেজেট") && !t.contains("রেজিস্টার্ড") &&
                    !t.contains("প্রজ্ঞাপন") && !t.contains("বাংলাদেশ সরকার") &&
                    t != "বাংলাদেশ"
                ) return t
            }
        }
        return fallback
    }
}
