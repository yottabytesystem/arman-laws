package com.foysal.lawai

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.foysal.lawai.data.Prefs

/**
 * AI settings. Everything here is optional — with no key the app still
 * answers from the loaded books. Several providers can be saved; one is the
 * active default and the rest act as automatic fallbacks.
 *
 * Only the key field shows by default; model and URL hide under "Advanced".
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var group: RadioGroup
    private lateinit var keyField: EditText
    private lateinit var modelField: EditText
    private lateinit var urlField: EditText
    private lateinit var advanced: LinearLayout
    private lateinit var advToggle: TextView
    private lateinit var savedList: TextView
    private lateinit var webBox: CheckBox
    private lateinit var fallbackBox: CheckBox
    private lateinit var hint: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        prefs = Prefs(this)
        group = findViewById(R.id.providerGroup)
        keyField = findViewById(R.id.apiKey)
        modelField = findViewById(R.id.model)
        urlField = findViewById(R.id.baseUrl)
        advanced = findViewById(R.id.advancedBox)
        advToggle = findViewById(R.id.advToggle)
        savedList = findViewById(R.id.savedList)
        webBox = findViewById(R.id.useWeb)
        fallbackBox = findViewById(R.id.useFallback)
        hint = findViewById(R.id.hint)

        webBox.isChecked = prefs.useWeb
        fallbackBox.isChecked = prefs.useFallback

        // Pre-fill from the active account if any.
        prefs.activeAccount()?.let {
            group.check(radioFor(it.provider))
            keyField.setText(it.apiKey)
            modelField.setText(it.model)
            urlField.setText(it.baseUrl)
        } ?: run {
            group.check(R.id.rbGemini)
            modelField.setText(Prefs.defaultModel(Prefs.GEMINI))
            urlField.setText(Prefs.defaultBaseUrl(Prefs.GEMINI))
        }

        group.setOnCheckedChangeListener { _, _ ->
            val p = selectedProvider()
            // Load saved key for that provider if it exists, else blank.
            val existing = prefs.accounts().firstOrNull { it.provider == p }
            keyField.setText(existing?.apiKey ?: "")
            modelField.setText(existing?.model?.ifBlank { Prefs.defaultModel(p) } ?: Prefs.defaultModel(p))
            urlField.setText(existing?.baseUrl?.ifBlank { Prefs.defaultBaseUrl(p) } ?: Prefs.defaultBaseUrl(p))
            updateHint()
        }

        advToggle.setOnClickListener {
            if (advanced.visibility == View.GONE) {
                advanced.visibility = View.VISIBLE
                advToggle.text = "▾ Advanced (model, URL)"
            } else {
                advanced.visibility = View.GONE
                advToggle.text = "▸ Advanced (model, URL)"
            }
        }

        findViewById<Button>(R.id.saveBtn).setOnClickListener { save() }
        findViewById<Button>(R.id.removeBtn).setOnClickListener { removeCurrent() }

        updateHint()
        refreshSaved()
    }

    private fun radioFor(p: String): Int = when (p) {
        Prefs.OPENAI -> R.id.rbOpenai
        Prefs.GROQ -> R.id.rbGroq
        Prefs.ANTHROPIC -> R.id.rbAnthropic
        else -> R.id.rbGemini
    }

    private fun selectedProvider(): String = when (group.checkedRadioButtonId) {
        R.id.rbOpenai -> Prefs.OPENAI
        R.id.rbGroq -> Prefs.GROQ
        R.id.rbAnthropic -> Prefs.ANTHROPIC
        else -> Prefs.GEMINI
    }

    private fun updateHint() {
        hint.text = when (selectedProvider()) {
            Prefs.GEMINI -> "Free key: aistudio.google.com — ~1500 requests/day, reads images."
            Prefs.GROQ -> "Free key: console.groq.com — very fast. Text only."
            Prefs.OPENAI -> "OpenAI, OpenRouter or Together — change the URL under Advanced."
            else -> "Anthropic Claude: console.anthropic.com"
        }
    }

    private fun refreshSaved() {
        val accts = prefs.accounts()
        if (accts.isEmpty()) {
            savedList.text = "No AI saved — app runs offline from books."
            return
        }
        val active = prefs.activeProvider
        savedList.text = "Saved: " + accts.joinToString(", ") {
            val star = if (it.provider == active) "★ " else ""
            star + Prefs.label(it.provider)
        } + "\n(★ = default, others are fallbacks)"
    }

    private fun save() {
        val p = selectedProvider()
        val key = keyField.text.toString().trim()
        if (key.isBlank()) {
            Toast.makeText(this, "Enter an API key first", Toast.LENGTH_SHORT).show()
            return
        }
        val acc = Prefs.Account(
            p, key,
            modelField.text.toString().trim().ifBlank { Prefs.defaultModel(p) },
            urlField.text.toString().trim().ifBlank { Prefs.defaultBaseUrl(p) }
        )
        prefs.addOrUpdate(acc)
        prefs.activeProvider = p          // the one you just saved becomes default
        prefs.useWeb = webBox.isChecked
        prefs.useFallback = fallbackBox.isChecked
        Toast.makeText(this, Prefs.label(p) + " saved & set as default", Toast.LENGTH_SHORT).show()
        refreshSaved()
    }

    private fun removeCurrent() {
        val p = selectedProvider()
        prefs.removeProvider(p)
        keyField.setText("")
        Toast.makeText(this, Prefs.label(p) + " removed", Toast.LENGTH_SHORT).show()
        refreshSaved()
    }
}
