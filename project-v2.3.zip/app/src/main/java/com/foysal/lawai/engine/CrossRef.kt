package com.foysal.lawai.engine

import com.foysal.lawai.data.Section

/**
 * Pulls out the section numbers a piece of legal text refers to, e.g.
 * "প্রবিধান ৪২ মোতাবেক", "ধারা ৩৯ এর দফা (ছ)", "উপ-প্রবিধান (২)".
 *
 * Used to show the sections a hit points at, so the reader does not have to
 * look them up separately.
 */
object CrossRef {

    private val REF = Regex(
        "(?:প্রবিধান|ধারা|বিধি|অনুচ্ছেদ)\\s*([০-৯0-9]{1,3})"
    )

    /** Section numbers (ascii) mentioned inside the given text. */
    fun referencedNumbers(text: String, selfNumber: String): Set<String> {
        val out = LinkedHashSet<String>()
        for (m in REF.findAll(text)) {
            val n = BengaliText.digitsToAscii(m.groupValues[1])
            if (n != selfNumber) out.add(n)
        }
        return out
    }

    /**
     * Given the hits, find referenced sections that are not already shown and
     * return them (deduped) so they can be appended as "related sections".
     */
    fun relatedFor(
        hits: List<com.foysal.lawai.data.Hit>,
        allByNumber: Map<String, Section>,
        limit: Int = 4
    ): List<Section> {
        val shown = hits.mapNotNull { it.section.number.ifBlank { null } }.toSet()
        val out = LinkedHashSet<Section>()
        for (h in hits) {
            for (ref in referencedNumbers(h.section.body, h.section.number)) {
                if (ref !in shown) {
                    allByNumber[ref]?.let { out.add(it) }
                    if (out.size >= limit) return out.toList()
                }
            }
        }
        return out.toList()
    }
}
