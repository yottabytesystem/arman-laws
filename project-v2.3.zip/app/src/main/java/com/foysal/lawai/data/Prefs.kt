package com.foysal.lawai.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * All settings. Nothing leaves the phone unless the user configures a key.
 *
 * Several providers can be saved at once; one is the active default and the
 * rest can be tried automatically as fallbacks when the active one fails or
 * runs out of quota.
 */
class Prefs(context: Context) {

    private val sp: SharedPreferences =
        context.getSharedPreferences("armanlaws_prefs", Context.MODE_PRIVATE)

    companion object {
        const val OPENAI = "openai"
        const val GEMINI = "gemini"
        const val GROQ = "groq"
        const val ANTHROPIC = "anthropic"

        fun defaultBaseUrl(p: String): String = when (p) {
            OPENAI -> "https://api.openai.com/v1/chat/completions"
            GROQ -> "https://api.groq.com/openai/v1/chat/completions"
            GEMINI -> "https://generativelanguage.googleapis.com/v1beta/models"
            ANTHROPIC -> "https://api.anthropic.com/v1/messages"
            else -> ""
        }

        fun defaultModel(p: String): String = when (p) {
            OPENAI -> "gpt-4o-mini"
            GROQ -> "llama-3.3-70b-versatile"
            GEMINI -> "gemini-2.0-flash"
            ANTHROPIC -> "claude-sonnet-4-5"
            else -> ""
        }

        fun label(p: String): String = when (p) {
            OPENAI -> "OpenAI / OpenRouter"
            GROQ -> "Groq (fast, free)"
            GEMINI -> "Google Gemini (free)"
            ANTHROPIC -> "Anthropic Claude"
            else -> p
        }

        /** Whether this provider's HTTP shape is OpenAI-compatible. */
        fun isOpenAiStyle(p: String): Boolean = p == OPENAI || p == GROQ
    }

    /** One saved provider configuration. */
    class Account(
        val provider: String,
        val apiKey: String,
        val model: String,
        val baseUrl: String
    ) {
        fun toJson(): JSONObject = JSONObject()
            .put("provider", provider)
            .put("key", apiKey)
            .put("model", model)
            .put("url", baseUrl)

        companion object {
            fun fromJson(o: JSONObject) = Account(
                o.optString("provider"),
                o.optString("key"),
                o.optString("model"),
                o.optString("url")
            )
        }
    }

    /** All saved accounts, in order (first = default). */
    fun accounts(): List<Account> {
        val raw = sp.getString("accounts", "") ?: ""
        if (raw.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                arr.optJSONObject(i)?.let { Account.fromJson(it) }
            }.filter { it.provider.isNotBlank() && it.apiKey.isNotBlank() }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveAccounts(list: List<Account>) {
        val arr = JSONArray()
        for (a in list) arr.put(a.toJson())
        sp.edit().putString("accounts", arr.toString()).apply()
    }

    fun addOrUpdate(account: Account) {
        val list = accounts().toMutableList()
        val idx = list.indexOfFirst { it.provider == account.provider }
        if (idx >= 0) list[idx] = account else list.add(account)
        saveAccounts(list)
    }

    fun removeProvider(provider: String) {
        saveAccounts(accounts().filterNot { it.provider == provider })
        if (activeProvider == provider) {
            activeProvider = accounts().firstOrNull()?.provider ?: ""
        }
    }

    /** The provider the user picked as default. */
    var activeProvider: String
        get() {
            val v = sp.getString("active", "") ?: ""
            if (v.isNotBlank() && accounts().any { it.provider == v }) return v
            return accounts().firstOrNull()?.provider ?: ""
        }
        set(v) = sp.edit().putString("active", v).apply()

    fun activeAccount(): Account? {
        val p = activeProvider
        return accounts().firstOrNull { it.provider == p } ?: accounts().firstOrNull()
    }

    /** Active first, then the rest — the order to try when falling back. */
    fun accountsInTryOrder(): List<Account> {
        val all = accounts()
        val active = activeProvider
        val head = all.filter { it.provider == active }
        val tail = all.filterNot { it.provider == active }
        return head + tail
    }

    var useFallback: Boolean
        get() = sp.getBoolean("fallback", true)
        set(v) = sp.edit().putBoolean("fallback", v).apply()

    var useWeb: Boolean
        get() = sp.getBoolean("use_web", true)
        set(v) = sp.edit().putBoolean("use_web", v).apply()

    var fontScale: Float
        get() = sp.getFloat("font_scale", 1.0f)
        set(v) = sp.edit().putFloat("font_scale", v).apply()

    val aiEnabled: Boolean
        get() = accounts().isNotEmpty()
}
