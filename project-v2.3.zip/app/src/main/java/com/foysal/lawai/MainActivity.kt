package com.foysal.lawai

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.foysal.lawai.data.LawRepository
import com.foysal.lawai.data.Prefs
import com.foysal.lawai.engine.AiClient
import com.foysal.lawai.engine.AnswerBuilder
import com.foysal.lawai.engine.CrossRef
import com.foysal.lawai.engine.DocxText
import com.foysal.lawai.engine.PdfText
import com.foysal.lawai.engine.WebSearch

/**
 * Arman Laws — single-screen console. Plain views in a ScrollView; no
 * RecyclerView, no Compose, nothing that can fail to compile.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var repo: LawRepository
    private lateinit var prefs: Prefs
    private lateinit var chatBox: LinearLayout
    private lateinit var scroller: ScrollView
    private lateinit var input: EditText
    private lateinit var sendBtn: Button
    private lateinit var status: TextView
    private lateinit var attachInfo: TextView

    private var ready = false

    // up to 5 images, base64 to mime
    private val images = ArrayList<Pair<String, String>>()
    // one attached document's extracted text
    private var docText: String? = null
    private var docName: String? = null

    private val pickBook =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importBook(uri)
        }
    private val pickImages =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (!uris.isNullOrEmpty()) attachImages(uris)
        }
    private val pickDoc =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) attachDoc(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        chatBox = findViewById(R.id.chatBox)
        scroller = findViewById(R.id.scroller)
        input = findViewById(R.id.input)
        sendBtn = findViewById(R.id.sendBtn)
        status = findViewById(R.id.status)
        attachInfo = findViewById(R.id.attachInfo)

        prefs = Prefs(this)
        repo = LawRepository(this)
        try { com.tom_roush.pdfbox.android.PDFBoxResourceLoader.init(applicationContext) } catch (e: Exception) {}

        findViewById<Button>(R.id.addBookBtn).setOnClickListener {
            pickBook.launch(arrayOf("application/pdf",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "text/plain", "text/*", "*/*"))
        }
        findViewById<Button>(R.id.libraryBtn).setOnClickListener { showLibrary() }
        findViewById<Button>(R.id.settingsBtn).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<Button>(R.id.imageBtn).setOnClickListener { pickImages.launch(arrayOf("image/*")) }
        findViewById<Button>(R.id.docBtn).setOnClickListener {
            pickDoc.launch(arrayOf("application/pdf",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "text/plain"))
        }
        attachInfo.setOnClickListener { clearAttachments() }
        sendBtn.setOnClickListener { submit() }

        greet()
        setBusy(true, "Indexing…")
        Thread {
            repo.initialize { msg -> runOnUiThread { status.text = msg } }
            runOnUiThread { ready = true; refreshStatus() }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        if (ready) refreshStatus()
    }

    private fun greet() {
        val mode = if (prefs.aiEnabled) "AI + books" else "Books (offline)"
        addBot(
            "┌─────────────────────────────┐\n" +
                "│  ARMAN LAWS                 │\n" +
                "└─────────────────────────────┘\n\n" +
                "Mode: $mode\n\n" +
                "Type your legal problem in Bengali. I find the relevant sections " +
                "from your books, with full text and source.\n\n" +
                "› 🖼 attach up to 5 images (office orders etc.)\n" +
                "› 📎 attach a PDF/DOCX/TXT with your question\n" +
                "› ＋ add your own law books\n" +
                "› ⚙ add an AI key for deeper written analysis"
        )
    }

    private fun refreshStatus() {
        val (books, sections) = repo.stats()
        val tag = if (prefs.aiEnabled) " • AI on" else ""
        status.text = "$books books · $sections sections$tag"
        sendBtn.isEnabled = true
        sendBtn.alpha = 1f
    }

    private fun setBusy(busy: Boolean, msg: String) {
        status.text = msg
        sendBtn.isEnabled = !busy
        sendBtn.alpha = if (busy) 0.4f else 1f
    }

    private fun submit() {
        val q = input.text.toString().trim()
        if (q.isEmpty() && images.isEmpty() && docText == null) return
        if (!ready) { Toast.makeText(this, "Still indexing", Toast.LENGTH_SHORT).show(); return }

        val imgs = ArrayList(images)
        val dtext = docText
        val dname = docName
        clearAttachments()
        input.setText("")

        val shown = buildString {
            if (q.isNotEmpty()) append(q)
            if (imgs.isNotEmpty()) append(if (isEmpty()) "" else "\n").append("🖼 ${imgs.size} image(s)")
            if (dname != null) append("\n📎 $dname")
        }
        addUser(shown.ifBlank { "(attachment)" })
        setBusy(true, "Searching…")

        Thread {
            // Combine the typed question with any attached document text for search.
            val searchQuery = (q + " " + (dtext ?: "")).trim().ifBlank { "office order" }
            val hits = repo.engine.search(searchQuery, 8)
            val defs = repo.engine.definitionsFor(searchQuery)
            val related = CrossRef.relatedFor(hits, repo.engine.firstByNumberMap(), 4)
            val (books, sections) = repo.stats()

            var web: List<WebSearch.Item> = emptyList()
            var webText = ""
            if (prefs.useWeb && q.isNotBlank() && WebSearch.isOnline()) {
                runOnUiThread { status.text = "Checking bdlaws…" }
                web = WebSearch.search(q, 4).items
                // With no AI and no local hits, pull the actual law text.
                if (!prefs.aiEnabled && hits.isEmpty() && web.isNotEmpty()) {
                    webText = WebSearch.fetchActText(web.first().url) ?: ""
                }
            }

            val answer = StringBuilder()
            if (prefs.aiEnabled) {
                runOnUiThread { status.text = "AI analysing…" }
                val ctx = buildString {
                    append(AnswerBuilder.contextForAi(hits))
                    if (dtext != null) append("\n=== ব্যবহারকারীর নথি ===\n").append(dtext.take(4000))
                }
                val reply = AiClient(prefs).ask(q.ifBlank { "সংযুক্ত নথি বিশ্লেষণ করো" }, ctx, imgs)
                if (reply.error == null) {
                    answer.append(reply.text)
                    answer.append("\n\n──── ব্যবহৃত উৎস ────\n")
                    answer.append(hits.joinToString("\n") { "• " + it.section.bookTitle + " | " + it.section.citation })
                    reply.usedProvider?.let { answer.append("\n\n[via ").append(Prefs.label(it)).append("]") }
                } else {
                    answer.append("⚠ AI failed (${reply.error}) — showing book answer:\n\n")
                    answer.append(AnswerBuilder.build(q, hits, books, sections, defs, related))
                }
            } else {
                if (imgs.isNotEmpty()) {
                    answer.append("⚠ Reading images needs an AI key (⚙ Settings). Using text only:\n\n")
                }
                answer.append(AnswerBuilder.build(q, hits, books, sections, defs, related))
                if (webText.isNotBlank()) {
                    answer.append("\n\n──── আইনের লেখা (bdlaws) ────\n")
                    answer.append(web.first().title).append("\n").append(web.first().url).append("\n\n")
                    answer.append(webText)
                }
            }
            answer.append(AnswerBuilder.webBlock(web))

            runOnUiThread {
                addBot(answer.toString())
                refreshStatus()
            }
        }.start()
    }

    private fun attachImages(uris: List<Uri>) {
        Thread {
            var added = 0
            for (uri in uris) {
                if (images.size >= 5) break
                val bytes = try {
                    contentResolver.openInputStream(uri)?.use { it.readBytes() }
                } catch (e: Exception) { null }
                if (bytes != null && bytes.isNotEmpty() && bytes.size <= 4 * 1024 * 1024) {
                    val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    val mime = contentResolver.getType(uri) ?: "image/jpeg"
                    images.add(b64 to mime)
                    added++
                }
            }
            runOnUiThread {
                if (added == 0) Toast.makeText(this, "No image added (max 5, ≤4MB each)", Toast.LENGTH_SHORT).show()
                updateAttachInfo()
            }
        }.start()
    }

    private fun attachDoc(uri: Uri) {
        val name = queryName(uri)
        setBusy(true, "Reading document…")
        Thread {
            val head = try {
                contentResolver.openInputStream(uri)?.use { val b = ByteArray(4); if (it.read(b) == 4) b else null }
            } catch (e: Exception) { null }
            var errMsg: String? = null
            val text: String = try {
                when {
                    DocxText.looksLikeDocx(name, head) ->
                        contentResolver.openInputStream(uri)?.use {
                            val r = DocxText.extract(it); errMsg = r.error; r.text
                        } ?: ""
                    PdfText.looksLikePdf(name, head) ->
                        contentResolver.openInputStream(uri)?.use {
                            val r = PdfText.extract(this, it); errMsg = r.error; r.text
                        } ?: ""
                    else ->
                        contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
                }
            } catch (e: Exception) { errMsg = e.message; "" }
            runOnUiThread {
                if (text.isBlank()) {
                    Toast.makeText(this, errMsg ?: "Could not read text from that file", Toast.LENGTH_LONG).show()
                } else {
                    docText = com.foysal.lawai.engine.BijoyConverter.let {
                        if (it.looksLikeBijoy(text)) it.convert(text) else text
                    }
                    docName = name
                    updateAttachInfo()
                }
                refreshStatus()
            }
        }.start()
    }

    private fun updateAttachInfo() {
        val parts = ArrayList<String>()
        if (images.isNotEmpty()) parts.add("🖼 ${images.size} image(s)")
        if (docName != null) parts.add("📎 $docName")
        if (parts.isEmpty()) { attachInfo.visibility = View.GONE; return }
        attachInfo.visibility = View.VISIBLE
        attachInfo.text = parts.joinToString("  ") + "  — tap to clear"
    }

    private fun clearAttachments() {
        images.clear(); docText = null; docName = null
        attachInfo.visibility = View.GONE
    }

    private fun importBook(uri: Uri) {
        val name = queryName(uri)
        setBusy(true, "Adding book…")
        Thread {
            val res = repo.importFromUri(uri, name)
            if (res.ok) repo.rebuildIndex { }
            runOnUiThread {
                if (res.ok) {
                    addBot("✓ Book added\n\nName: ${res.title}\nSections: ${res.sectionCount}" +
                        if (res.bijoyConverted) "\nBijoy → Unicode converted" else "")
                } else {
                    addBot("✗ Could not add: ${res.error}\n\nSupported: .pdf, .docx, .txt")
                }
                refreshStatus()
            }
        }.start()
    }

    private fun queryName(uri: Uri): String {
        var name = uri.lastPathSegment ?: "file"
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) name = c.getString(idx)
            }
        } catch (e: Exception) {}
        return name
    }

    private fun showLibrary() {
        val books = repo.books()
        if (books.isEmpty()) { Toast.makeText(this, "No books", Toast.LENGTH_SHORT).show(); return }
        val total = books.sumOf { it.sectionCount }
        val labels = books.map { "${it.title}\n   ${it.sectionCount} sections" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Books: ${books.size} · Sections: $total")
            .setItems(labels) { _, which -> confirmDelete(books[which].id, books[which].title) }
            .setPositiveButton("Close", null)
            .show()
    }

    private fun confirmDelete(id: Long, title: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage("Delete this book?")
            .setNegativeButton("No", null)
            .setPositiveButton("Delete") { _, _ ->
                Thread {
                    repo.deleteBook(id); repo.rebuildIndex { }
                    runOnUiThread { refreshStatus(); Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show() }
                }.start()
            }
            .show()
    }

    private fun addUser(t: String) = bubble("আপনি:\n" + t, true)
    private fun addBot(t: String) = bubble(t, false)

    private fun bubble(text: String, isUser: Boolean) {
        val tv = TextView(this)
        tv.text = text
        tv.setTextIsSelectable(true)
        tv.typeface = Typeface.MONOSPACE
        tv.setTextColor(if (isUser) Color.parseColor("#FFD98A") else Color.parseColor("#B9F5D8"))
        tv.setBackgroundResource(if (isUser) R.drawable.bubble_user else R.drawable.bubble_bot)
        tv.textSize = 13f * prefs.fontScale
        tv.setPadding(dp(12), dp(10), dp(12), dp(10))
        tv.setLineSpacing(dp(3).toFloat(), 1f)

        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(5); lp.bottomMargin = dp(5)
        lp.leftMargin = if (isUser) dp(36) else 0
        lp.rightMargin = if (isUser) 0 else dp(16)
        lp.gravity = if (isUser) Gravity.END else Gravity.START
        tv.layoutParams = lp

        // long-press any bot message to copy or share
        if (!isUser) {
            tv.setOnLongClickListener {
                AlertDialog.Builder(this)
                    .setItems(arrayOf("Copy", "Share")) { _, which ->
                        if (which == 0) {
                            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("Arman Laws", text))
                            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
                        } else {
                            val i = Intent(Intent.ACTION_SEND).setType("text/plain")
                                .putExtra(Intent.EXTRA_TEXT, text)
                            startActivity(Intent.createChooser(i, "Share"))
                        }
                    }.show()
                true
            }
        }

        chatBox.addView(tv)
        if (isUser) {
            scroller.post { scroller.fullScroll(View.FOCUS_DOWN) }
        } else {
            // Bring the TOP of the answer into view so the user reads from the start.
            scroller.post { scroller.smoothScrollTo(0, tv.top) }
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
