package com.foysal.lawai.engine

/**
 * Bijoy / SutonnyMJ  ->  Unicode Bangla converter.
 *
 * Legacy Bangladeshi documents (Gazette PDFs, old Word files) store Bangla as
 * ASCII glyph codes for a specific font instead of real Unicode. Converting is
 * mandatory before any search or indexing can work.
 *
 * Handles:
 *   - multi-character conjuncts (longest match first)
 *   - reph reordering        (Kg\u00A9  ->  \u0995\u09B0\u09CD\u09AE)
 *   - pre-kar reordering     (\u2020Kvb ->  \u0995\u09CB\u09A8)
 *   - nukta composition      (\u09AF + \u09BC -> \u09DF)
 *
 * Auto-generated map - do not hand-edit.
 */
object BijoyConverter {

    private const val REPH = "\uE000"

    private val GLYPH: LinkedHashMap<String, String> = linkedMapOf(
        "M\u00AAy" to "\u0997\u09CD\u09B0\u09C1",
        "`\u00AA\u201C" to "\u09A6\u09CD\u09B0\u09C1",
        "\u00A4c\u00D6" to "\u09AE\u09CD\u09AA\u09CD\u09B0",
        "\u0161\u2014\u00A1" to "\u09A8\u09CD\u09A4\u09CD\u09AC",
        "\u201DQ\u00A1" to "\u099A\u09CD\u099B\u09CD\u09AC",
        "Av" to "\u0986",
        "K\u00A1" to "\u0995\u09CD\u09AC",
        "K\u00AC" to "\u0995\u09CD\u09B2",
        "M\u00A5" to "\u0997\u09CD\u09AE",
        "M\u00AD" to "\u0997\u09CD\u09B2",
        "M\u0153" to "\u0997\u09CD\u09A8",
        "R\u00A1" to "\u099C\u09CD\u09AC",
        "U\u00A1" to "\u099F\u09CD\u09AC",
        "U\u00A5" to "\u099F\u09CD\u09AE",
        "Y^" to "\u09A3\u09CD\u09AC",
        "Z\u00A1" to "\u09A4\u09CD\u09AC",
        "Z\u00A5" to "\u09A4\u09CD\u09AE",
        "Z\u0153" to "\u09A4\u09CD\u09A8",
        "\\&" to "\u09CD\u200C",
        "\\^" to "\u09CD\u09AC",
        "\\|" to "\u0964",
        "_\u00A1" to "\u09A5\u09CD\u09AC",
        "a\u00A5" to "\u09A7\u09CD\u09AE",
        "a\u0178" to "\u09A7\u09CD\u09AC",
        "b\u00A5" to "\u09A8\u09CD\u09AE",
        "b\u0153" to "\u09A8\u09CD\u09A8",
        "c\u00AD" to "\u09AA\u09CD\u09B2",
        "c\u0153" to "\u09AA\u09CD\u09A8",
        "d\u00AC" to "\u09AB\u09CD\u09B2",
        "e\u00AD" to "\u09AC\u09CD\u09B2",
        "e\u0178" to "\u09AC\u09CD\u09AC",
        "g\u0153" to "\u09AE\u09CD\u09A8",
        "i\u00A8" to "\u09B0\u200C\u09CD\u09AF",
        "i\u00E6" to "\u09B0\u09C1",
        "i\u0192" to "\u09B0\u09C2",
        "i\u201C" to "\u09B0\u09C1",
        "j\u00A5" to "\u09B2\u09CD\u09AE",
        "j\u00A6" to "\u09B2\u09CD\u09AC",
        "j\u00AD" to "\u09B2\u09CD\u09B2",
        "k\u00A5" to "\u09B6\u09CD\u09AE",
        "k\u00A6" to "\u09B6\u09CD\u09AC",
        "k\u00AD" to "\u09B6\u09CD\u09B2",
        "k\u0153" to "\u09B6\u09CD\u09A8",
        "m\u0153" to "\u09B8\u09CD\u09A8",
        "n\u00AC" to "\u09B9\u09CD\u09B2",
        "n\u00E8" to "\u09B9\u09CD\u09A3",
        "n\u0178" to "\u09B9\u09CD\u09AC",
        "\u00A4^" to "\u09AE\u09CD\u09AC",
        "\u00A4\u00A2" to "\u09AE\u09CD\u09AD",
        "\u00A4\u00A3" to "\u09AE\u09CD\u09AD\u09CD\u09B0",
        "\u00A4\u00A7" to "\u09AE\u09CD\u09AE",
        "\u00A4\u00AD" to "\u09AE\u09CD\u09B2",
        "\u00A4\u00FA" to "\u09AE\u09CD\u09AA",
        "\u00AA\u00A8" to "\u09CD\u09B0\u09CD\u09AF",
        "\u00AE\u00A7" to "\u09B7\u09CD\u09AE",
        "\u00AE\u00FA" to "\u09B7\u09CD\u09AA",
        "\u00AE\u0152" to "\u09B7\u09CD\u0995\u09CD\u09B0",
        "\u00AE\u2039" to "\u09B7\u09CD\u0995",
        "\u00AF^" to "\u09B8\u09CD\u09AC",
        "\u00AF\u00A7" to "\u09B8\u09CD\u09AE",
        "\u00AF\u00AD" to "\u09B8\u09CD\u09B2",
        "\u00AF\u00BF" to "\u09B8\u09CD\u09A4\u09CD\u09B0",
        "\u00AF\u00CD" to "\u09B8\u09CD\u09A4",
        "\u00AF\u00FA" to "\u09B8\u09CD\u09AA",
        "\u00AF\u0152" to "\u09B8\u09CD\u0995\u09CD\u09B0",
        "\u00AF\u2014" to "\u09B8\u09CD\u09A4",
        "\u00AF\u2018" to "\u09B8\u09CD\u09A4\u09C1",
        "\u00AF\u2019" to "\u09B8\u09CD\u09A5",
        "\u00AF\u2039" to "\u09B8\u09CD\u0995",
        "\u00BE\u00A1" to "\u099C\u09CD\u099C\u09CD\u09AC",
        "\u00CB\u00A1" to "\u09A4\u09CD\u09A4\u09CD\u09AC",
        "\u0161^" to "\u09A8\u09CD\u09AC",
        "\u0161\u00BF" to "\u09A8\u09CD\u09A4\u09CD\u09B0",
        "\u0161\u00CD" to "\u09A8\u09CD\u09A4",
        "\u0161\u2014" to "\u09A8\u09CD\u09A4",
        "\u0161\u2018" to "\u09A8\u09CD\u09A4\u09C1",
        "\u0161\u2019" to "\u09A8\u09CD\u09A5",
        "\u02DCM" to "\u09A6\u09CD\u0997",
        "\u02DCN" to "\u09A6\u09CD\u0998",
        "\u201DP" to "\u099A\u09CD\u099A",
        "\u201DQ" to "\u099A\u09CD\u099B",
        "\u201DT" to "\u099A\u09CD\u099E",
        "\u201E\u201E" to "\u09C3",
        "\u2022L" to "\u0999\u09CD\u0996",
        "\u2022N" to "\u0999\u09CD\u0998",
        "\u2022\u00B6" to "\u0999\u09CD\u0995\u09CD\u09B7",
        "\u203AU" to "\u09A8\u09CD\u099F",
        "\u203A`" to "\u09A8\u09CD\u09A6",
        "\u203A\u00D8" to "\u09A8\u09CD\u09A6\u09CD\u09AC",
        "\u2122\u00A2" to "\u09A6\u09CD\u09AD",
        "&" to "\u09CD",
        "0" to "\u09E6",
        "1" to "\u09E7",
        "2" to "\u09E8",
        "3" to "\u09E9",
        "4" to "\u09EA",
        "5" to "\u09EB",
        "6" to "\u09EC",
        "7" to "\u09ED",
        "8" to "\u09EE",
        "9" to "\u09EF",
        "A" to "\u0985",
        "B" to "\u0987",
        "C" to "\u0988",
        "D" to "\u0989",
        "E" to "\u098A",
        "F" to "\u098B",
        "G" to "\u098F",
        "H" to "\u0990",
        "I" to "\u0993",
        "J" to "\u0994",
        "K" to "\u0995",
        "L" to "\u0996",
        "M" to "\u0997",
        "N" to "\u0998",
        "O" to "\u0999",
        "P" to "\u099A",
        "Q" to "\u099B",
        "R" to "\u099C",
        "S" to "\u099D",
        "T" to "\u099E",
        "U" to "\u099F",
        "V" to "\u09A0",
        "W" to "\u09A1",
        "X" to "\u09A2",
        "Y" to "\u09A3",
        "Z" to "\u09A4",
        "_" to "\u09A5",
        "`" to "\u09A6",
        "a" to "\u09A7",
        "b" to "\u09A8",
        "c" to "\u09AA",
        "d" to "\u09AB",
        "e" to "\u09AC",
        "f" to "\u09AD",
        "g" to "\u09AE",
        "h" to "\u09AF",
        "i" to "\u09B0",
        "j" to "\u09B2",
        "k" to "\u09B6",
        "l" to "\u09B7",
        "m" to "\u09B8",
        "n" to "\u09B9",
        "o" to "\u09DC",
        "p" to "\u09DD",
        "q" to "\u09DF",
        "r" to "\u09CE",
        "s" to "\u0982",
        "t" to "\u0983",
        "u" to "\u0981",
        "v" to "\u09BE",
        "w" to "\u09BF",
        "x" to "\u09C0",
        "y" to "\u09C1",
        "z" to "\u09C1",
        "|" to "\u0964",
        "~" to "\u09C2",
        "\u00A1" to "\u09CD\u09AC",
        "\u00A2" to "\u09CD\u09AD",
        "\u00A3" to "\u09CD\u09AD\u09CD\u09B0",
        "\u00A4" to "\u09AE\u09CD",
        "\u00A5" to "\u09CD\u09AE",
        "\u00A6" to "\u09CD\u09AC",
        "\u00A7" to "\u09CD\u09AE",
        "\u00A8" to "\u09CD\u09AF",
        "\u00A9" to "\uE000",
        "\u00AA" to "\u09CD\u09B0",
        "\u00AB" to "\u09CD\u09B0",
        "\u00AC" to "\u09CD\u09B2",
        "\u00AD" to "\u09CD\u09B2",
        "\u00AE" to "\u09B7\u09CD",
        "\u00AF" to "\u09B8\u09CD",
        "\u00B0" to "\u0995\u09CD\u0995",
        "\u00B1" to "\u0995\u09CD\u099F",
        "\u00B2" to "\u0995\u09CD\u09B7\u09CD\u09AE",
        "\u00B3" to "\u0995\u09CD\u09A4",
        "\u00B4" to "\u0995\u09CD\u09AE",
        "\u00B5" to "\u0995\u09CD\u09B0",
        "\u00B6" to "\u0995\u09CD\u09B7",
        "\u00B7" to "\u0995\u09CD\u09B8",
        "\u00B8" to "\u0997\u09C1",
        "\u00B9" to "\u099C\u09CD\u099E",
        "\u00BA" to "\u0997\u09CD\u09A6",
        "\u00BB" to "\u0997\u09CD\u09A7",
        "\u00BC" to "\u0999\u09CD\u0995",
        "\u00BD" to "\u0999\u09CD\u0997",
        "\u00BE" to "\u099C\u09CD\u099C",
        "\u00BF" to "\u09CD\u09A4\u09CD\u09B0",
        "\u00C0" to "\u099C\u09CD\u099D",
        "\u00C1" to "\u099C\u09CD\u099E",
        "\u00C2" to "\u099E\u09CD\u099A",
        "\u00C3" to "\u099E\u09CD\u099B",
        "\u00C4" to "\u099E\u09CD\u099C",
        "\u00C5" to "\u099E\u09CD\u099D",
        "\u00C6" to "\u099F\u09CD\u099F",
        "\u00C7" to "\u09A1\u09CD\u09A1",
        "\u00C8" to "\u09A3\u09CD\u099F",
        "\u00C9" to "\u09A3\u09CD\u09A0",
        "\u00CA" to "\u09A3\u09CD\u09A1",
        "\u00CB" to "\u09A4\u09CD\u09A4",
        "\u00CC" to "\u09A4\u09CD\u09A5",
        "\u00CD" to "\u09CD\u09A4",
        "\u00CE" to "\u09A4\u09CD\u09B0",
        "\u00CF" to "\u09A6\u09CD\u09A6",
        "\u00D0" to "\u09A3\u09CD\u09A1",
        "\u00D1" to "-",
        "\u00D2" to "\u201C",
        "\u00D3" to "\u201D",
        "\u00D4" to "\u2018",
        "\u00D5" to "\u2019",
        "\u00D6" to "\u09CD\u09B0",
        "\u00D7" to "\u09A6\u09CD\u09A7",
        "\u00D8" to "\u09A6\u09CD\u09AC",
        "\u00D9" to "\u09A6\u09CD\u09AE",
        "\u00DA" to "\u09A8\u09CD\u09A0",
        "\u00DB" to "\u09A8\u09CD\u09A1",
        "\u00DC" to "\u09A8\u09CD\u09A7",
        "\u00DD" to "\u09A8\u09CD\u09B8",
        "\u00DE" to "\u09AA\u09CD\u099F",
        "\u00DF" to "\u09AA\u09CD\u09A4",
        "\u00E0" to "\u09AA\u09CD\u09AA",
        "\u00E1" to "\u09AA\u09CD\u09B8",
        "\u00E2" to "\u09AC\u09CD\u099C",
        "\u00E3" to "\u09AC\u09CD\u09A6",
        "\u00E4" to "\u09AC\u09CD\u09A7",
        "\u00E5" to "\u09AD\u09CD\u09B0",
        "\u00E6" to "\u09C1",
        "\u00E7" to "\u09AE\u09CD\u09AB",
        "\u00E8" to "\u09CD\u09A8",
        "\u00E9" to "\u09B2\u09CD\u0995",
        "\u00EA" to "\u09B2\u09CD\u0997",
        "\u00EB" to "\u09B2\u09CD\u099F",
        "\u00EC" to "\u09B2\u09CD\u09A1",
        "\u00ED" to "\u09B2\u09CD\u09AA",
        "\u00EE" to "\u09B2\u09CD\u09AB",
        "\u00EF" to "\u09B6\u09C1",
        "\u00F0" to "\u09B6\u09CD\u099A",
        "\u00F1" to "\u09B6\u09CD\u099B",
        "\u00F2" to "\u09B7\u09CD\u09A3",
        "\u00F3" to "\u09B7\u09CD\u099F",
        "\u00F4" to "\u09B7\u09CD\u09A0",
        "\u00F5" to "\u09B7\u09CD\u09AB",
        "\u00F6" to "\u09B8\u09CD\u0996",
        "\u00F7" to "\u09B8\u09CD\u099F",
        "\u00F8" to "\u09CD\u09B2",
        "\u00F9" to "\u09B8\u09CD\u09AB",
        "\u00FA" to "\u09CD\u09AA",
        "\u00FB" to "\u09B9\u09C1",
        "\u00FC" to "\u09B9\u09C3",
        "\u00FD" to "\u09B9\u09CD\u09A8",
        "\u00FE" to "\u09B9\u09CD\u09AE",
        "\u00FF" to "\u0995\u09CD\u09B7",
        "\u0152" to "\u09CD\u0995\u09CD\u09B0",
        "\u0153" to "\u09CD\u09A8",
        "\u0160" to "\u09D7",
        "\u0161" to "\u09A8\u09CD",
        "\u0178" to "\u09CD\u09AC",
        "\u0192" to "\u09C2",
        "\u02C6" to "\u09C8",
        "\u02DC" to "\u09A6\u09CD",
        "\u2013" to "\u09C1",
        "\u2014" to "\u09CD\u09A4",
        "\u2018" to "\u09CD\u09A4\u09C1",
        "\u2019" to "\u09CD\u09A5",
        "\u201A" to "\u09C2",
        "\u201C" to "\u09C1",
        "\u201D" to "\u099A\u09CD",
        "\u201E" to "\u09C3",
        "\u2020" to "\u09C7",
        "\u2021" to "\u09C7",
        "\u2022" to "\u0999\u09CD",
        "\u2026" to "\u09C3",
        "\u2030" to "\u09C8",
        "\u2039" to "\u09CD\u0995",
        "\u203A" to "\u09A8\u09CD",
        "\u2122" to "\u09A6\u09CD",
        "\u23AF" to "",
    )

    private val byLen: Map<Int, Map<String, String>> =
        GLYPH.entries.groupBy { it.key.length }
            .mapValues { e -> e.value.associate { it.key to it.value } }

    private val maxKey: Int = GLYPH.keys.maxOf { it.length }

    private val CONS: Set<Char> = "\u0995\u0996\u0997\u0998\u0999\u099A\u099B\u099C\u099D\u099E\u099F\u09A0\u09A1\u09A2\u09A3\u09A4\u09A5\u09A6\u09A7\u09A8\u09AA\u09AB\u09AC\u09AD\u09AE\u09AF\u09B0\u09B2\u09B6\u09B7\u09B8\u09B9\u09CE\u09DC\u09DD\u09DF".toSet()
    private val VOWELS: Set<Char> = "\u0985\u0986\u0987\u0988\u0989\u098A\u098B\u098F\u0990\u0993\u0994".toSet()
    private val POST_SIGNS: Set<Char> = "\u0981\u0982\u0983\u09BC\u09BE\u09C0\u09C1\u09C2\u09C3\u09CB\u09CC\u09CD\u09D7\u200C\u200D".toSet()
    private val PRE_KARS: Set<Char> = "\u09BF\u09C7\u09C8".toSet()
    private const val HALANT = '\u09CD'
    private const val REPH_CH = '\uE000'

    /** True if the text looks like legacy Bijoy rather than Unicode Bangla. */
    fun looksLikeBijoy(text: String): Boolean {
        if (text.isEmpty()) return false
        var bangla = 0
        var marker = 0
        for (c in text) {
            if (c in '\u0980'..'\u09FF') bangla++
            if (c in "\u2020\u2021\u00A9\u00D6\u00A8\u00AF\u009A\u00BF\u2018\u2019\u201C\u201D\u00B8\u00E6\u0192") marker++
        }
        return bangla * 4 < text.length && marker > text.length / 200
    }

    fun convert(input: String): String {
        if (input.isEmpty()) return input
        val mapped = mapGlyphs(input)
        val composed = mapped
            .replace("\u09AF\u09BC", "\u09DF")
            .replace("\u09A1\u09BC", "\u09DC")
            .replace("\u09A2\u09BC", "\u09DD")
        var out = reorder(composed)
        out = out.replace("\u09C7\u09BE", "\u09CB")
            .replace("\u09C7\u09D7", "\u09CC")
            .replace("\u0985\u09BE", "\u0986")
            .replace("\u09CD\u09CD", "\u09CD")
        return out.replace(Regex("[ \t]+"), " ")
    }

    private fun mapGlyphs(s: String): String {
        val sb = StringBuilder(s.length + 16)
        var i = 0
        val n = s.length
        while (i < n) {
            var hitLen = 0
            var hitVal: String? = null
            var l = minOf(maxKey, n - i)
            while (l >= 1) {
                val seg = s.substring(i, i + l)
                val v = byLen[l]?.get(seg)
                if (v != null) { hitLen = l; hitVal = v; break }
                l--
            }
            if (hitVal != null) { sb.append(hitVal); i += hitLen }
            else { sb.append(s[i]); i++ }
        }
        return sb.toString()
    }

    private class Cluster(var cons: String, var signs: String, var reph: Boolean, var next: Int)

    private fun readCluster(s: String, start: Int): Cluster {
        val n = s.length
        var i = start
        val cons = StringBuilder()
        var reph = false
        cons.append(s[i]); i++
        while (true) {
            while (i < n && s[i] == REPH_CH) { reph = true; i++ }
            if (i + 1 < n && s[i] == HALANT && s[i + 1] in CONS) {
                cons.append(s[i]).append(s[i + 1]); i += 2
            } else break
        }
        val signs = StringBuilder()
        while (i < n && (s[i] in POST_SIGNS || s[i] == REPH_CH)) {
            if (s[i] == REPH_CH) reph = true else signs.append(s[i])
            i++
        }
        return Cluster(cons.toString(), signs.toString(), reph, i)
    }

    private fun reorder(s: String): String {
        val out = StringBuilder(s.length + 16)
        var i = 0
        val n = s.length
        while (i < n) {
            val ch = s[i]
            when {
                ch in PRE_KARS -> {
                    val kars = StringBuilder()
                    while (i < n && s[i] in PRE_KARS) { kars.append(s[i]); i++ }
                    if (i < n && (s[i] in CONS || s[i] in VOWELS)) {
                        val c = readCluster(s, i)
                        if (c.reph) out.append("\u09B0\u09CD")
                        out.append(c.cons).append(kars).append(c.signs)
                        i = c.next
                    } else out.append(kars)
                }
                ch in CONS || ch in VOWELS -> {
                    val c = readCluster(s, i)
                    if (c.reph) out.append("\u09B0\u09CD")
                    out.append(c.cons).append(c.signs)
                    i = c.next
                }
                ch == REPH_CH -> i++
                else -> { out.append(ch); i++ }
            }
        }
        return out.toString()
    }
}
