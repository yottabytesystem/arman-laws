package com.foysal.lawai.engine

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

/**
 * Reads the text out of a .docx (or .dotx) file.
 *
 * A .docx is just a ZIP containing `word/document.xml`, so this needs no
 * library at all - no Apache POI, no extra megabytes, nothing that can break
 * the build. We pull that one entry out and strip the XML.
 *
 * Paragraph and line breaks are preserved, which matters a lot here: the
 * section parser works line by line, so losing them would merge every
 * regulation into one blob.
 */
object DocxText {

    private val PARAGRAPH_END = Regex("</w:p>")
    private val LINE_BREAK = Regex("<w:br\\s*/?>|<w:cr\\s*/?>")
    private val TAB = Regex("<w:tab\\s*/?>")
    private val TEXT_NODE = Regex("<w:t(?:\\s[^>]*)?>(.*?)</w:t>", RegexOption.DOT_MATCHES_ALL)
    private val ANY_TAG = Regex("<[^>]+>")

    class Result(val text: String, val error: String?)

    fun looksLikeDocx(name: String, firstBytes: ByteArray?): Boolean {
        if (name.endsWith(".docx", ignoreCase = true) ||
            name.endsWith(".dotx", ignoreCase = true)
        ) return true
        // A ZIP header alone is not enough (an .apk is also a ZIP), so only
        // treat it as docx when the name gives no other clue.
        if (firstBytes != null && firstBytes.size >= 2 &&
            firstBytes[0] == 'P'.code.toByte() && firstBytes[1] == 'K'.code.toByte()
        ) {
            return !name.contains('.')
        }
        return false
    }

    fun extract(input: InputStream): Result {
        return try {
            var xml: String? = null
            ZipInputStream(input).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (entry.name == "word/document.xml") {
                        val out = ByteArrayOutputStream()
                        val buf = ByteArray(16 * 1024)
                        while (true) {
                            val n = zip.read(buf)
                            if (n <= 0) break
                            out.write(buf, 0, n)
                        }
                        xml = out.toString("UTF-8")
                        break
                    }
                    zip.closeEntry()
                }
            }
            val doc = xml
                ?: return Result("", "এটি বৈধ .docx ফাইল নয় (word/document.xml পাওয়া যায়নি)")

            val text = xmlToText(doc)
            if (text.isBlank()) {
                Result("", "ডকুমেন্টে কোনো লেখা নেই")
            } else {
                Result(text, null)
            }
        } catch (e: OutOfMemoryError) {
            Result("", "ফাইলটি খুব বড়, মেমোরিতে ধরছে না")
        } catch (e: Exception) {
            Result("", "ফাইল পড়া যায়নি: " + (e.message ?: "অজানা ত্রুটি"))
        }
    }

    private fun xmlToText(xml: String): String {
        // Mark structure before deleting tags, otherwise every line runs together.
        var s = xml
        s = LINE_BREAK.replace(s, "\n")
        s = TAB.replace(s, "\t")
        s = PARAGRAPH_END.replace(s, "\n</w:p>")

        val sb = StringBuilder(s.length / 4)
        var last = 0
        for (m in TEXT_NODE.findAll(s)) {
            // keep newlines that sit between text nodes
            val between = s.substring(last, m.range.first)
            if (between.contains('\n')) sb.append('\n')
            sb.append(unescape(ANY_TAG.replace(m.groupValues[1], "")))
            last = m.range.last + 1
        }
        return sb.toString()
            .replace("\u00A0", " ")
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()
    }

    private fun unescape(s: String): String = s
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&apos;", "'")
        .replace("&amp;", "&")
}
