package com.foysal.lawai.engine

import com.foysal.lawai.data.Prefs
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * Talks to whichever AI the user configured. Uses only HttpURLConnection and
 * org.json (both built into Android) so there is no extra dependency.
 *
 * Supports several saved accounts: it tries the active one first, and if that
 * fails and fallback is on, moves to the next until one answers.
 */
class AiClient(private val prefs: Prefs) {

    class Reply(val text: String, val error: String?, val usedProvider: String?)

    fun ask(
        question: String,
        context: String,
        images: List<Pair<String, String>>   // base64 to mime
    ): Reply {
        val order = prefs.accountsInTryOrder()
        if (order.isEmpty()) return Reply("", "API সেট করা নেই", null)

        val tryList = if (prefs.useFallback) order else order.take(1)
        var lastError = "সংযোগে সমস্যা"

        for (acc in tryList) {
            val r = try {
                when (acc.provider) {
                    Prefs.GEMINI -> gemini(acc, question, context, images)
                    Prefs.ANTHROPIC -> anthropic(acc, question, context, images)
                    else -> openai(acc, question, context, images)   // openai + groq
                }
            } catch (e: Exception) {
                Reply("", e.message ?: "সংযোগে সমস্যা", null)
            }
            if (r.error == null) return Reply(r.text, null, acc.provider)
            lastError = r.error
        }
        return Reply("", lastError, null)
    }

    private fun systemPrompt(context: String): String = buildString {
        append("তুমি একজন দক্ষ বাংলাদেশি আইন বিশ্লেষক। ব্যবহারকারীর সমস্যার ")
        append("ব্যবহারিক সমাধান দাও — পরিষ্কার বাংলায়, ধাপে ধাপে।\n\n")
        append("নিয়ম:\n")
        append("১. নিচের আইনের অংশগুলোই প্রধান ভিত্তি। যা লেখা আছে তার বাইরে বানাবে না।\n")
        append("২. প্রতিটি দাবির পাশে বইয়ের নাম ও ধারা নম্বর লিখবে, যেমন [<বই>, ধারা ২৪]।\n")
        append("৩. দেওয়া অংশে উত্তর না থাকলে স্পষ্ট বলবে কোন তথ্য নেই।\n")
        append("৪. ছবি বা নথি দেওয়া থাকলে তার লেখা পড়ে সমস্যার সাথে মিলিয়ে বিশ্লেষণ করবে।\n")
        append("৫. উপসংহারে করণীয় ধাপগুলো সংক্ষেপে লিখবে।\n\n")
        append("=== আইনের প্রাসঙ্গিক অংশ ===\n")
        append(context.ifBlank { "(কোনো প্রাসঙ্গিক অংশ পাওয়া যায়নি)" })
    }

    // ---------- OpenAI-compatible: OpenAI, OpenRouter, Groq ----------
    private fun openai(acc: Prefs.Account, q: String, ctx: String, imgs: List<Pair<String, String>>): Reply {
        val body = JSONObject()
        body.put("model", acc.model.ifBlank { Prefs.defaultModel(acc.provider) })
        body.put("max_tokens", 2000)

        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", systemPrompt(ctx)))

        val userMsg = JSONObject().put("role", "user")
        if (imgs.isNotEmpty()) {
            val parts = JSONArray()
            parts.put(JSONObject().put("type", "text").put("text", q))
            for ((b64, mime) in imgs) {
                parts.put(
                    JSONObject().put("type", "image_url").put(
                        "image_url", JSONObject().put("url", "data:$mime;base64,$b64")
                    )
                )
            }
            userMsg.put("content", parts)
        } else {
            userMsg.put("content", q)
        }
        messages.put(userMsg)
        body.put("messages", messages)

        val resp = post(acc.baseUrl.ifBlank { Prefs.defaultBaseUrl(acc.provider) },
            body.toString(), mapOf("Authorization" to "Bearer ${acc.apiKey}"))
            ?: return Reply("", "কোনো উত্তর আসেনি", null)

        val json = JSONObject(resp)
        json.optJSONObject("error")?.let { return Reply("", it.optString("message", "API ত্রুটি"), null) }
        val text = json.optJSONArray("choices")?.optJSONObject(0)
            ?.optJSONObject("message")?.optString("content") ?: ""
        return if (text.isBlank()) Reply("", "খালি উত্তর", null) else Reply(text, null, null)
    }

    // ---------- Google Gemini ----------
    private fun gemini(acc: Prefs.Account, q: String, ctx: String, imgs: List<Pair<String, String>>): Reply {
        val base = acc.baseUrl.ifBlank { Prefs.defaultBaseUrl(acc.provider) }
        val model = acc.model.ifBlank { Prefs.defaultModel(acc.provider) }
        val url = "$base/$model:generateContent?key=${acc.apiKey}"

        val parts = JSONArray()
        parts.put(JSONObject().put("text", systemPrompt(ctx) + "\n\n=== প্রশ্ন ===\n" + q))
        for ((b64, mime) in imgs) {
            parts.put(JSONObject().put("inline_data",
                JSONObject().put("mime_type", mime).put("data", b64)))
        }
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts)))

        val resp = post(url, body.toString(), emptyMap())
            ?: return Reply("", "কোনো উত্তর আসেনি", null)

        val json = JSONObject(resp)
        json.optJSONObject("error")?.let { return Reply("", it.optString("message", "API ত্রুটি"), null) }
        val text = json.optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")
            ?.optJSONObject(0)?.optString("text") ?: ""
        return if (text.isBlank()) Reply("", "খালি উত্তর", null) else Reply(text, null, null)
    }

    // ---------- Anthropic ----------
    private fun anthropic(acc: Prefs.Account, q: String, ctx: String, imgs: List<Pair<String, String>>): Reply {
        val body = JSONObject()
        body.put("model", acc.model.ifBlank { Prefs.defaultModel(acc.provider) })
        body.put("max_tokens", 2000)
        body.put("system", systemPrompt(ctx))

        val content = JSONArray()
        for ((b64, mime) in imgs) {
            content.put(JSONObject().put("type", "image").put("source",
                JSONObject().put("type", "base64").put("media_type", mime).put("data", b64)))
        }
        content.put(JSONObject().put("type", "text").put("text", q))
        body.put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))

        val resp = post(acc.baseUrl.ifBlank { Prefs.defaultBaseUrl(acc.provider) },
            body.toString(), mapOf("x-api-key" to acc.apiKey, "anthropic-version" to "2023-06-01"))
            ?: return Reply("", "কোনো উত্তর আসেনি", null)

        val json = JSONObject(resp)
        json.optJSONObject("error")?.let { return Reply("", it.optString("message", "API ত্রুটি"), null) }
        val text = json.optJSONArray("content")?.optJSONObject(0)?.optString("text") ?: ""
        return if (text.isBlank()) Reply("", "খালি উত্তর", null) else Reply(text, null, null)
    }

    private fun post(urlStr: String, body: String, headers: Map<String, String>): String? {
        var conn: HttpURLConnection? = null
        return try {
            conn = URL(urlStr).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = 90000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            OutputStreamWriter(conn.outputStream, "UTF-8").use { it.write(body) }
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            BufferedReader(InputStreamReader(stream, "UTF-8")).use { it.readText() }
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}
