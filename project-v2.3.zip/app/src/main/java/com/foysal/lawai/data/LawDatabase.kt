package com.foysal.lawai.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Plain SQLite storage. No Room, no annotation processing - fewer moving parts
 * means the project actually compiles on a clean CI runner.
 */
class LawDatabase(context: Context) :
    SQLiteOpenHelper(context.applicationContext, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME = "lawai.db"
        private const val DB_VERSION = 1
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE books(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                file_name TEXT NOT NULL UNIQUE,
                added_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE sections(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                book_id INTEGER NOT NULL,
                chapter TEXT NOT NULL DEFAULT '',
                number TEXT NOT NULL DEFAULT '',
                heading TEXT NOT NULL DEFAULT '',
                body TEXT NOT NULL,
                FOREIGN KEY(book_id) REFERENCES books(id)
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_sections_book ON sections(book_id)")
        db.execSQL("CREATE INDEX idx_sections_number ON sections(number)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS sections")
        db.execSQL("DROP TABLE IF EXISTS books")
        onCreate(db)
    }

    fun hasBook(fileName: String): Boolean {
        readableDatabase.rawQuery(
            "SELECT 1 FROM books WHERE file_name=? LIMIT 1", arrayOf(fileName)
        ).use { return it.moveToFirst() }
    }

    fun insertBook(title: String, fileName: String): Long {
        val cv = ContentValues().apply {
            put("title", title)
            put("file_name", fileName)
            put("added_at", System.currentTimeMillis())
        }
        return writableDatabase.insertWithOnConflict(
            "books", null, cv, SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun insertSections(bookId: Long, rows: List<Array<String>>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val stmt = db.compileStatement(
                "INSERT INTO sections(book_id, chapter, number, heading, body) VALUES(?,?,?,?,?)"
            )
            for (r in rows) {
                stmt.clearBindings()
                stmt.bindLong(1, bookId)
                stmt.bindString(2, r[0])
                stmt.bindString(3, r[1])
                stmt.bindString(4, r[2])
                stmt.bindString(5, r[3])
                stmt.executeInsert()
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun fileNameOf(bookId: Long): String? {
        readableDatabase.rawQuery(
            "SELECT file_name FROM books WHERE id=?", arrayOf(bookId.toString())
        ).use { c -> if (c.moveToFirst()) return c.getString(0) }
        return null
    }

    fun deleteBook(bookId: Long) {
        writableDatabase.delete("sections", "book_id=?", arrayOf(bookId.toString()))
        writableDatabase.delete("books", "id=?", arrayOf(bookId.toString()))
    }

    fun listBooks(): List<Book> {
        val out = ArrayList<Book>()
        readableDatabase.rawQuery(
            """
            SELECT b.id, b.title, b.file_name, COUNT(s.id)
            FROM books b LEFT JOIN sections s ON s.book_id = b.id
            GROUP BY b.id ORDER BY b.added_at
            """.trimIndent(), null
        ).use { c ->
            while (c.moveToNext()) {
                out.add(Book(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3)))
            }
        }
        return out
    }

    fun loadAllSections(): List<Section> {
        val out = ArrayList<Section>()
        readableDatabase.rawQuery(
            """
            SELECT s.id, s.book_id, b.title, s.chapter, s.number, s.heading, s.body
            FROM sections s JOIN books b ON b.id = s.book_id
            ORDER BY s.book_id, s.id
            """.trimIndent(), null
        ).use { c ->
            while (c.moveToNext()) {
                out.add(
                    Section(
                        id = c.getLong(0),
                        bookId = c.getLong(1),
                        bookTitle = c.getString(2),
                        chapter = c.getString(3),
                        number = c.getString(4),
                        heading = c.getString(5),
                        body = c.getString(6)
                    )
                )
            }
        }
        return out
    }
}
